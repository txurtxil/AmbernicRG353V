#!/bin/sh
export TERM=linux
export TERMINFO=/storage/terminfo
export DIALOGRC=/storage/.dialogrc

# Garantizar módulos de control
modprobe joydev 2>/dev/null
modprobe uinput 2>/dev/null
chmod 666 /dev/uinput 2>/dev/null

# Limpiar y arrancar controles
killall -9 gptokeyb 2>/dev/null
pkill -9 -f l1_listener.sh 2>/dev/null

/usr/bin/gptokeyb "foot" -c "/storage/scripts/keyb/universal.gptk" &
nohup /storage/scripts/keyb/l1_listener.sh > /dev/null 2>&1 &

get_stats() {
    IP=$(ip route get 1 2>/dev/null | awk '{print $7;exit}' || echo "OFFLINE")
    BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "??")
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null | awk '{print int($1/1000)}')
    echo "[ IP: $IP | BAT: $BAT% | TEMP: $TEMP'C ]"
}

while true; do
    INFO=$(get_stats)
    dialog --timeout 60 --ascii-lines --shadow --clear \
    --backtitle "CyberDeck OS - GOLDEN MASTER" \
    --title " $INFO " \
    --menu "SISTEMA CENTRAL" 18 64 8 \
    "SHELL"    "Terminal Principal" \
    "HTOP"     "Monitor de Recursos" \
    "KALI"     "Herramientas de Red" \
    "SETTINGS" "Ajustes del Sistema" \
    "EXIT"     "Salir al Terminal" 2> /tmp/choice.txt
    
    [ $? -ne 0 ] && continue
    CHOICE=$(cat /tmp/choice.txt | tr -d '[:space:]')
    clear
    case "$CHOICE" in
        "SHELL") /storage/scripts/start_war_room.sh ;;
        "HTOP")  /storage/scripts/bin/tmux new-session -A -s htop "htop" ;;
        "KALI")  /storage/scripts/start_kali_multitask.sh ;;
        "SETTINGS") /storage/scripts/settings_tmux.sh ;;
        "EXIT") break ;;
    esac
done
