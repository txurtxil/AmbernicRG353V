#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux

TMUX_BIN="/storage/scripts/bin/tmux"
TMUX_CONF="/storage/.tmux.conf"

# Capturar dimensiones usando stty (compatible con sistemas mínimos como Rocknix)
DIMS=$(stty size 2>/dev/null)
if [ -n "$DIMS" ]; then
    LINES=$(echo "$DIMS" | awk '{print $1}')
    COLS=$(echo "$DIMS" | awk '{print $2}')
else
    # Paracaídas de seguridad por si falla la lectura
    LINES=40
    COLS=120
fi

# 1. Limpieza de sesión previa con pausa de seguridad
$TMUX_BIN -f $TMUX_CONF kill-session -t settings 2>/dev/null
sleep 0.2

# 2. Pestaña 1: WIFI (Usamos -x e -y para forzar el lienzo al tamaño real de tu pantalla)
$TMUX_BIN -f $TMUX_CONF new-session -d -x $COLS -y $LINES -s settings -n 'WIFI'
$TMUX_BIN send-keys -t settings:WIFI 'clear; /storage/scripts/cyber_wifi.sh' C-m

# 3. Pestaña 2: BT
$TMUX_BIN new-window -t settings -n 'BT'
$TMUX_BIN send-keys -t settings:BT 'clear; /storage/scripts/cyber_bt.sh' C-m

# 4. Pestaña 3: TESTS
$TMUX_BIN new-window -t settings -n 'TESTS'
$TMUX_BIN send-keys -t settings:TESTS 'clear; /storage/scripts/net_tools.sh' C-m

# 5. Pestaña 4: SHELL
$TMUX_BIN new-window -t settings -n 'SHELL'
$TMUX_BIN send-keys -t settings:SHELL 'clear' C-m

# 6. Pestaña 5: HTOP
$TMUX_BIN new-window -t settings -n 'HTOP'
$TMUX_BIN send-keys -t settings:HTOP 'clear; htop' C-m

# 7. Pestaña 6: SISTEMA
$TMUX_BIN new-window -t settings -n 'SISTEMA'
$TMUX_BIN send-keys -t settings:SISTEMA 'clear; /storage/scripts/sys_ctrl.sh' C-m

# --- AJUSTES TÁCTICOS DE NAVEGACIÓN MULTITAREA ---
$TMUX_BIN set-option -t settings prefix C-b

# R1 (Mapeado como Tab) para AVANZAR a la siguiente pestaña
$TMUX_BIN bind-key -n Tab next-window

# L1 (Mapeado como Backspace) para RETROCEDER a la pestaña anterior
$TMUX_BIN bind-key -n BSpace previous-window

# Seleccionar la primera ventana y entrar al War-Room
$TMUX_BIN select-window -t settings:WIFI
$TMUX_BIN attach-session -t settings
