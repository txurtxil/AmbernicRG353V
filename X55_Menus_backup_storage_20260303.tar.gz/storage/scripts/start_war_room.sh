#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux

# 1. Crear sesión principal (LOCAL)
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s cyberdeck -n 'LOCAL'

# 2. Crear ventana KALI vacía e inyectar el comando de Docker
/storage/scripts/bin/tmux new-window -t cyberdeck:2 -n 'KALI'
/storage/scripts/bin/tmux send-keys -t cyberdeck:2 '/storage/docker/bin/docker run -it --rm --net=host --privileged kali-cyberdeck:latest /bin/bash' C-m

# 3. Crear ventana MONITOR vacía e inyectar htop
/storage/scripts/bin/tmux new-window -t cyberdeck:3 -n 'MONITOR'
/storage/scripts/bin/tmux send-keys -t cyberdeck:3 'htop' C-m

# 4. Seleccionar la primera ventana y mostrar la sesión
/storage/scripts/bin/tmux select-window -t cyberdeck:1
/storage/scripts/bin/tmux attach-session -t cyberdeck
