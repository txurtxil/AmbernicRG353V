#!/bin/bash
export XDG_RUNTIME_DIR=/tmp/xdg
mkdir -p /tmp/xdg
chmod 700 /tmp/xdg
[ -e /tmp/xdg/wayland-0 ] && export WAYLAND_DISPLAY=wayland-0 || export WAYLAND_DISPLAY=wayland-1

killall -9 wvkbd 2>/dev/null
sleep 0.1
# wvkbd limpio, sin parámetros que causen error de Wayland
/storage/scripts/keyb/wvkbd &
