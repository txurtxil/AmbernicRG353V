#!/bin/bash
export TERM=linux
export TERMINFO=/storage/terminfo
export DIALOGRC=/storage/.dialogrc

while true; do
    BT_STATE=$(hciconfig hci0 2>/dev/null | grep -o "UP RUNNING\|DOWN")
    [ -z "$BT_STATE" ] && BT_STATE="NO DETECTADO"

    dialog --clear --ascii-lines --shadow \
    --title " PANEL BLUETOOTH " \
    --menu "Estado Hardware: $BT_STATE\n\nSelecciona una accion:" 15 50 6 \
    "SCAN"    "BUSCAR Dispositivos (Analisis Profundo)" \
    "ON"      "Encender Controlador" \
    "OFF"     "Apagar Controlador" \
    "PAIRED"  "Ver Dispositivos Vinculados" \
    "REMOVE"  "Olvidar Dispositivos" \
    "SALIR"   "Volver" 2> /tmp/bt_panel.txt

    [ $? -ne 0 ] && break
    ACT=$(cat /tmp/bt_panel.txt)

    case "$ACT" in
        "SCAN")
            cat << 'INNER' > /tmp/bt_scan_task.sh
#!/bin/bash
echo "[*] Reiniciando demonio Bluetooth..."
systemctl restart bluetooth 2>/dev/null
sleep 1

echo "[*] Preparando hci0..."
rfkill unblock bluetooth 2>/dev/null
hciconfig hci0 down 2>/dev/null
sleep 1
hciconfig hci0 up 2>/dev/null
sleep 1

echo "[*] Limpiando procesos previos..."
pkill -9 -f bluetoothctl 2>/dev/null

echo "[*] Fase 1: Escaneo de espectro general (14s)..."
(
    echo "power on"
    echo "agent on"
    echo "default-agent"
    echo "discoverable on"
    echo "pairable on"
    echo "scan on"
    sleep 14
    echo "scan off"
    echo "quit"
) | bluetoothctl > /dev/null 2>&1 &
SCAN_PID=$!

for i in {1..14}; do
    echo "    -> Escuchando frecuencias... $i/14"
    sleep 1
done

wait $SCAN_PID 2>/dev/null

echo "[*] Fase 2: Interrogatorio Profundo (Forzando resolucion)..."
# Leemos lo que hay y quitamos colores
bluetoothctl devices > /tmp/bt_temp_raw.txt 2>&1
sed -i 's/\x1b\[[0-9;]*m//g' /tmp/bt_temp_raw.txt

# Disparamos peticiones directas a los dispositivos rebeldes
while read -r line; do
    if echo "$line" | grep -q "^Device"; then
        MAC=$(echo "$line" | awk '{print $2}')
        NAME=$(echo "$line" | cut -d' ' -f3-)
        MAC_HYPHEN=$(echo "$MAC" | tr ':' '-')
        
        # Si no tiene nombre, le lanzamos un dardo directo
        if [ "$NAME" == "$MAC_HYPHEN" ] || [ -z "$NAME" ]; then
            echo "    -> Interrogando MAC oculta: $MAC"
            echo "info $MAC" | timeout 1.5s bluetoothctl >/dev/null 2>&1
        fi
    fi
done < /tmp/bt_temp_raw.txt

echo "[*] Generando informe final..."
bluetoothctl devices > /tmp/bt_list_raw.txt 2>&1
sed -i 's/\x1b\[[0-9;]*m//g' /tmp/bt_list_raw.txt
sleep 1
INNER
            chmod +x /tmp/bt_scan_task.sh
            
            dialog --title " DIAGNOSTICO DE ESCANEO " --prgbox "/tmp/bt_scan_task.sh" 22 70
            
            > /tmp/bt_named.txt
            > /tmp/bt_unnamed.txt
            
            if [ -f /tmp/bt_list_raw.txt ]; then
                while read -r line; do
                    if echo "$line" | grep -q "^Device"; then
                        MAC=$(echo "$line" | awk '{print $2}')
                        NAME=$(echo "$line" | cut -d' ' -f3-)
                        
                        MAC_HYPHEN=$(echo "$MAC" | tr ':' '-')
                        if [ "$NAME" == "$MAC_HYPHEN" ] || [ -z "$NAME" ]; then
                            NAME="[Desconocido / Privado]"
                            echo "\"$MAC\" \"$NAME\"" >> /tmp/bt_unnamed.txt
                        else
                            echo "\"$MAC\" \"$NAME\"" >> /tmp/bt_named.txt
                        fi
                    fi
                done < /tmp/bt_list_raw.txt
            fi

            cat /tmp/bt_named.txt /tmp/bt_unnamed.txt > /tmp/bt_list.txt

            if [ -s /tmp/bt_list.txt ]; then
                dialog --title " RESULTADOS ORDENADOS " --menu "Selecciona para vincular:" 18 65 10 --file /tmp/bt_list.txt 2> /tmp/target_mac.txt
                if [ $? -eq 0 ]; then
                    MAC=$(cat /tmp/target_mac.txt)
                    
                    cat << 'PAIR_TASK' > /tmp/bt_pair_task.sh
#!/bin/bash
MAC=$1
echo "[*] Ejecutando comandos de vinculacion para $MAC..."
(
    echo "agent on"
    echo "default-agent"
    echo "pair $MAC"
    sleep 5
    echo "trust $MAC"
    sleep 1
    echo "connect $MAC"
    sleep 4
    echo "quit"
) | bluetoothctl
echo ""
echo "[*] Proceso finalizado. Presiona OK para volver."
PAIR_TASK
                    chmod +x /tmp/bt_pair_task.sh
                    dialog --title " VINCULANDO A $MAC " --prgbox "/tmp/bt_pair_task.sh $MAC" 20 65
                fi
            else
                dialog --msgbox "La lista esta vacia.\nAsegurate de que tus dispositivos esten visibles y prueba otra vez." 6 60
            fi
            ;;
        "ON")  
            rfkill unblock bluetooth
            hciconfig hci0 up >/dev/null 2>&1 
            ;;
        "OFF") 
            hciconfig hci0 down >/dev/null 2>&1 
            ;;
        "PAIRED")
            timeout 3s bluetoothctl paired-devices > /tmp/paired_raw.txt
            sed -i 's/\x1b\[[0-9;]*m//g' /tmp/paired_raw.txt
            if [ -s /tmp/paired_raw.txt ]; then
                dialog --title " DISPOSITIVOS VINCULADOS " --textbox /tmp/paired_raw.txt 15 60
            else
                dialog --msgbox "No hay dispositivos vinculados o el demonio no responde." 6 60
            fi
            ;;
        "REMOVE")
            timeout 3s bluetoothctl paired-devices > /tmp/bt_paired_raw.txt
            sed -i 's/\x1b\[[0-9;]*m//g' /tmp/bt_paired_raw.txt
            > /tmp/bt_paired.txt
            while read -r line; do
                if echo "$line" | grep -q "^Device"; then
                    MAC=$(echo "$line" | awk '{print $2}')
                    NAME=$(echo "$line" | cut -d' ' -f3-)
                    
                    MAC_HYPHEN=$(echo "$MAC" | tr ':' '-')
                    if [ "$NAME" == "$MAC_HYPHEN" ] || [ -z "$NAME" ]; then
                        NAME="[Desconocido / Privado]"
                    fi

                    echo "\"$MAC\" \"$NAME\"" >> /tmp/bt_paired.txt
                fi
            done < /tmp/bt_paired_raw.txt
            
            if [ -s /tmp/bt_paired.txt ]; then
                dialog --title " OLVIDAR DISPOSITIVO " --menu "Selecciona cual eliminar:" 15 65 8 --file /tmp/bt_paired.txt 2> /tmp/remove_mac.txt
                if [ $? -eq 0 ]; then
                    RM_MAC=$(cat /tmp/remove_mac.txt)
                    echo -e "remove $RM_MAC\nquit" | timeout 5s bluetoothctl >/dev/null 2>&1
                    dialog --msgbox "Dispositivo $RM_MAC eliminado." 5 50
                fi
            else
                dialog --msgbox "No hay dispositivos vinculados para borrar." 5 45
            fi
            ;;
        "SALIR") break ;;
    esac
done
