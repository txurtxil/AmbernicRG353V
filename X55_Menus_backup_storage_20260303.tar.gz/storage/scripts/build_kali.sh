#!/bin/bash
DOCKER="/storage/docker/bin/docker"

echo -e "\033[1;36m[*] Comprobando conexion a internet...\033[0m"
ping -c 1 8.8.8.8 >/dev/null 2>&1 || { echo -e "\033[1;31m[!] ERROR: No hay internet. Conecta el Wi-Fi desde el menu NET y vuelve a intentarlo.\033[0m"; exit 1; }

echo -e "\033[1;33m[*] Limpiando contenedores temporales atascados...\033[0m"
$DOCKER rm -f kali_forge 2>/dev/null

echo -e "\033[1;34m[*] Descargando arsenal (Nmap, Ping, MACChanger, etc). Esto puede tardar unos minutos...\033[0m"
$DOCKER run --name kali_forge --net=host kalilinux/kali-rolling:arm64 bash -c "apt-get update && apt-get install -y nmap iputils-ping net-tools macchanger tcpdump dnsutils"

if [ $? -eq 0 ]; then
    echo -e "\033[1;35m[*] Arsenal descargado. Sellando la imagen tactica definitiva...\033[0m"
    $DOCKER commit kali_forge kali-cyberdeck:latest
    $DOCKER rm kali_forge
    echo -e "\n\033[1;32m[+] EXITO ABSOLUTO: La imagen 'kali-cyberdeck' esta lista y armada.\033[0m"
else
    echo -e "\n\033[1;31m[-] ERROR: La descarga fallo. Revisa tu conexion a internet.\033[0m"
fi
