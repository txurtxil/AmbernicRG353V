#!/bin/bash
export TERM=linux
export TERMINFO=/storage/terminfo
export DIALOGRC=/storage/.dialogrc
export PATH=$PATH:/usr/bin:/usr/sbin:/bin:/sbin

while true; do
    # 1. Extracción de IP (limpia)
    IP=$(ip -4 addr show wlan0 2>/dev/null | grep "inet" | awk '{print $2}' | cut -d/ -f1 | head -n 1)
    [ -z "$IP" ] && IP="Sin IP asignada"

    # 2. Extracción de SSID activo (iw puro)
    SSID=$(iw dev wlan0 link 2>/dev/null | grep "\bSSID:" | sed 's/^\s*SSID: //')
    [ -z "$SSID" ] && SSID="DESCONECTADO"

    dialog --clear --ascii-lines --shadow \
    --title " PANEL DE COMUNICACIONES WI-FI " \
    --menu "Enlace: $SSID\nIPv4: $IP\n\nSelecciona un vector de accion:" 17 65 7 \
    "SCAN"    "Escanear y Seleccionar Red (Interactivo)" \
    "SAVED"   "Gestionar Redes Guardadas (Memoria)" \
    "HIDDEN"  "Conectar a Red Oculta (Manual)" \
    "ON"      "Activar Radio (Hardware RFKILL)" \
    "OFF"     "Desactivar Radio (Modo Avion)" \
    "RESTART" "Forzar Renegociacion de Enlace (DHCP)" \
    "STATUS"  "Diagnostico de Interfaz e IP" \
    "SALIR"   "Volver" 2> /tmp/wifi_action.txt

    [ $? -ne 0 ] && break
    ACT=$(cat /tmp/wifi_action.txt)

    case "$ACT" in
        "SCAN")
            dialog --infobox "Activando antena y barriendo el espectro...\n(Espera 4 segundos)" 4 50
            rfkill unblock wifi 2>/dev/null
            ip link set wlan0 up 2>/dev/null
            sleep 2
            
            # Extraemos SSIDs limpios y sin duplicados
            > /tmp/wifi_list.txt
            iw dev wlan0 scan 2>/dev/null | grep "\bSSID:" | sed 's/^\s*SSID: //' | grep -v "^$" | sort -u > /tmp/wifi_raw.txt
            
            while read -r line; do
                echo "\"$line\" \"Autenticar\"" >> /tmp/wifi_list.txt
            done < /tmp/wifi_raw.txt

            if [ -s /tmp/wifi_list.txt ]; then
                dialog --title " RADAR WI-FI " --menu "Selecciona el objetivo:" 18 65 10 --file /tmp/wifi_list.txt 2> /tmp/w_target.txt
                if [ $? -eq 0 ]; then
                    TARGET_SSID=$(cat /tmp/w_target.txt)
                    
                    dialog --title " PROTOCOLO DE SEGURIDAD " --insecure --passwordbox "Introduce la contraseña para:\n[$TARGET_SSID]\n\n(Deja en blanco si es una red ABIERTA)" 10 55 2> /tmp/w_pass.txt
                    if [ $? -eq 0 ]; then
                        TARGET_PASS=$(cat /tmp/w_pass.txt)
                        dialog --infobox "Inyectando credenciales y negociando enlace...\nPor favor, espera 8 segundos." 5 55
                        
                        # Limpiamos perfiles antiguos con el mismo nombre para evitar conflictos
                        EXISTING_IDS=$(wpa_cli -i wlan0 list_networks | grep "\b$TARGET_SSID\b" | awk '{print $1}')
                        for ID in $EXISTING_IDS; do
                            wpa_cli -i wlan0 remove_network $ID >/dev/null
                        done
                        
                        # Creamos el nuevo perfil
                        NET_ID=$(wpa_cli -i wlan0 add_network 2>/dev/null)
                        if echo "$NET_ID" | grep -q '^[0-9]\+$'; then
                            wpa_cli -i wlan0 set_network $NET_ID ssid "\"$TARGET_SSID\"" >/dev/null
                            if [ -z "$TARGET_PASS" ]; then
                                wpa_cli -i wlan0 set_network $NET_ID key_mgmt NONE >/dev/null
                            else
                                wpa_cli -i wlan0 set_network $NET_ID psk "\"$TARGET_PASS\"" >/dev/null
                            fi
                            wpa_cli -i wlan0 enable_network $NET_ID >/dev/null
                            wpa_cli -i wlan0 save_config >/dev/null
                            
                            # Forzamos la obtención de IP
                            wpa_cli -i wlan0 reassociate >/dev/null
                            sleep 8
                        else
                            dialog --msgbox "Error critico: No se pudo inyectar en wpa_supplicant." 5 55
                        fi
                    fi
                fi
            else
                dialog --msgbox "El radar no encontro ninguna red Wi-Fi.\nAsegurate de que la antena esta en ON." 6 50
            fi
            ;;
            
        "SAVED")
            > /tmp/w_saved_menu.txt
            wpa_cli -i wlan0 list_networks > /tmp/w_saved_raw.txt
            
            while read -r line; do
                ID=$(echo "$line" | awk '{print $1}')
                NET_SSID=$(echo "$line" | awk '{print $2}')
                # Filtramos para asegurarnos de que el ID es un numero (ignoramos la cabecera)
                if echo "$ID" | grep -q '^[0-9]\+$'; then
                     echo "\"$ID\" \"$NET_SSID\"" >> /tmp/w_saved_menu.txt
                fi
            done < /tmp/w_saved_raw.txt
            
            if [ -s /tmp/w_saved_menu.txt ]; then
                dialog --title " REDES EN MEMORIA " --menu "Selecciona una red guardada para OLVIDARLA:" 18 60 10 --file /tmp/w_saved_menu.txt 2> /tmp/w_del_id.txt
                if [ $? -eq 0 ]; then
                    DEL_ID=$(cat /tmp/w_del_id.txt)
                    wpa_cli -i wlan0 remove_network $DEL_ID >/dev/null
                    wpa_cli -i wlan0 save_config >/dev/null
                    dialog --infobox "Red eliminada de la memoria." 3 40
                    sleep 1
                fi
            else
                dialog --msgbox "No hay redes guardadas en la memoria del dispositivo." 5 55
            fi
            ;;

        "HIDDEN")
            dialog --title " OBJETIVO OCULTO " --inputbox "Introduce el SSID exacto de la red:" 8 50 2> /tmp/w_ssid.txt
            if [ $? -eq 0 ]; then
                TARGET_SSID=$(cat /tmp/w_ssid.txt)
                [ -z "$TARGET_SSID" ] && continue
                
                dialog --title " SEGURIDAD " --insecure --passwordbox "Introduce la clave:" 8 50 2> /tmp/w_pass.txt
                if [ $? -eq 0 ]; then
                    TARGET_PASS=$(cat /tmp/w_pass.txt)
                    dialog --infobox "Aplicando configuracion..." 3 40
                    
                    NET_ID=$(wpa_cli -i wlan0 add_network 2>/dev/null)
                    wpa_cli -i wlan0 set_network $NET_ID ssid "\"$TARGET_SSID\"" >/dev/null
                    wpa_cli -i wlan0 set_network $NET_ID scan_ssid 1 >/dev/null
                    [ -n "$TARGET_PASS" ] && wpa_cli -i wlan0 set_network $NET_ID psk "\"$TARGET_PASS\"" >/dev/null
                    wpa_cli -i wlan0 enable_network $NET_ID >/dev/null
                    wpa_cli -i wlan0 save_config >/dev/null
                    sleep 5
                fi
            fi
            ;;
            
        "ON")  
            dialog --infobox "Activando sistemas de radio..." 3 40
            rfkill unblock wifi 2>/dev/null
            rfkill unblock wlan 2>/dev/null
            ip link set wlan0 up 2>/dev/null
            wpa_cli -i wlan0 reconfigure 2>/dev/null
            sleep 2
            ;;
            
        "OFF") 
            dialog --infobox "Cortando transmisiones..." 3 40
            wpa_cli -i wlan0 disconnect 2>/dev/null
            ip link set wlan0 down 2>/dev/null
            rfkill block wifi 2>/dev/null
            rfkill block wlan 2>/dev/null
            sleep 2
            ;;
            
        "RESTART")
            dialog --infobox "Forzando renegociacion de IP..." 3 45
            ip link set wlan0 down 2>/dev/null
            sleep 1
            ip link set wlan0 up 2>/dev/null
            wpa_cli -i wlan0 reassociate 2>/dev/null
            sleep 4
            ;;
            
        "STATUS")
            INFO=$(iw dev wlan0 link 2>/dev/null || echo "Desconectado")
            ROUTE=$(ip route | grep default || echo "Sin puerta de enlace")
            DNS=$(cat /etc/resolv.conf 2>/dev/null | grep nameserver | awk '{print $2}' | paste -sd ", " || echo "Sin DNS")
            dialog --title " DIAGNOSTICO DE RED " --msgbox "--- ENLACE FISICO ---\n$INFO\n\n--- RUTAS ---\n$ROUTE\n\n--- DNS ---\n$DNS" 20 70
            ;;
            
        "SALIR") break ;;
    esac
done
