#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux

# 1. ROOT
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s kali_suite -n 'ROOT'
/storage/scripts/bin/tmux send-keys -t kali_suite:1 '/storage/docker/bin/docker run -it --rm --net=host --privileged kali-cyberdeck:latest /bin/bash' C-m
/storage/scripts/bin/tmux send-keys -t kali_suite:1 'clear; echo -e "\033[1;31m[+] KALI LINUX: SISTEMA CENTRAL [+]\033[0m"' C-m

# 2. RECON (NMAP Y ARP INTERACTIVO)
/storage/scripts/bin/tmux new-window -t kali_suite:2 -n 'RECON'
/storage/scripts/bin/tmux send-keys -t kali_suite:2 '/storage/scripts/kali_recon.sh' C-m

# 3. EXPLOIT (ARSENAL INTERACTIVO)
/storage/scripts/bin/tmux new-window -t kali_suite:3 -n 'EXPLOIT'
/storage/scripts/bin/tmux send-keys -t kali_suite:3 '/storage/scripts/kali_exploit.sh' C-m

# 4. SNIFF (TCPDUMP AVANZADO)
/storage/scripts/bin/tmux new-window -t kali_suite:4 -n 'SNIFF'
/storage/scripts/bin/tmux send-keys -t kali_suite:4 '/storage/scripts/kali_sniff.sh' C-m

# 5. LOGS (MIDNIGHT COMMANDER)
/storage/scripts/bin/tmux new-window -t kali_suite:5 -n 'LOGS'
# Arranca con el panel izquierdo en /logs y el derecho en /storage
/storage/scripts/bin/tmux send-keys -t kali_suite:5 '/storage/docker/bin/docker run -it --rm -v /:/host_root -v /storage:/storage -w /storage/kali/logs --privileged kali-cyberdeck:latest mc /storage/kali/logs /storage' C-m

# 6. MONITOR (HTOP)
/storage/scripts/bin/tmux new-window -t kali_suite:6 -n 'MONITOR'
/storage/scripts/bin/tmux send-keys -t kali_suite:6 'htop' C-m

# Mostrar la interfaz
/storage/scripts/bin/tmux select-window -t kali_suite:1
/storage/scripts/bin/tmux attach-session -t kali_suite
