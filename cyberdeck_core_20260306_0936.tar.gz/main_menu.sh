#!/bin/sh
export LC_ALL=C
export LANG=C
export TERM=linux
export TERMINFO=/storage/terminfo

export DOCKER="/storage/scripts/docker/bin/docker"
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin


modprobe joydev 2>/dev/null
modprobe uinput 2>/dev/null
chmod 666 /dev/uinput 2>/dev/null

killall -9 gptokeyb 2>/dev/null
nohup /storage/scripts/keyb/l1_listener.sh > /dev/null 2>&1 &
export SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1
export SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1

/usr/bin/gptokeyb "foot" -c "/storage/scripts/keyb/universal.gptk" &
nohup /storage/scripts/keyb/l1_listener.sh > /dev/null 2>&1 &

get_stats() {
    IP=$(ip route get 1 2>/dev/null | awk '{print $7;exit}' || echo "OFFLINE")
    BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "??")
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null | awk '{print int($1/1000)}')
    echo "[ IP: $IP | BAT: $BAT% | TEMP: $TEMP'C ]"
}

while true; do
    INFO=$(get_stats)
    export DIALOGRC=/storage/.dialogrc_main
    
    dialog --timeout 60 --ascii-lines --shadow --clear \
    --backtitle "CyberDeck OS - SISTEMA CENTRAL" \
    --title " $INFO " \
    --menu "SELECCIONA MODULO" ${LINES:-50} ${COLUMNS:-150} 20 \
    "SHELL"    "Terminal Principal (Con Tabs)" \
    "DEV"      "Entorno de Desarrollo" \
    "GTOP"     "Monitor de Sistema (Gtop)" \
    "KALI"     "Suite Ofensiva Kali (Multitarea)" \
    "SETTINGS" "Ajustes del Sistema" \
    "POWER"    "Opciones de Energia y Apagado" 2> /tmp/choice.txt
    
    [ $? -ne 0 ] && continue
    CHOICE=$(cat /tmp/choice.txt | tr -d '[:space:]')
    clear
    
    case "$CHOICE" in
        "SHELL") /storage/scripts/start_war_room.sh ;;
        "DEV") /storage/scripts/submenu_desarrollo.sh ;;
        "GTOP") /storage/scripts/bin/tmux new-session -A -s gtop "gtop --utf-force" ;;
        "KALI") 
            export DIALOGRC=/storage/.dialogrc_kali
            dialog --msgbox "Desplegando entorno tactico de Kali..." 5 45
            /storage/scripts/start_kali_multitask.sh 
            ;;
        "SETTINGS") /storage/scripts/settings_tmux.sh ;;
        "POWER") 
            /storage/scripts/submenu_power.sh 
            # Si el submenu devuelve el codigo 99, rompemos el bucle y salimos a terminal
            if [ $? -eq 99 ]; then
                break
            fi
            ;;
    esac
done
