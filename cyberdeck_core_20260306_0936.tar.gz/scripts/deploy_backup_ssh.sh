#!/bin/sh

echo "[*] 1. AÑADIENDO SSH AL MENU IZQUIERDO DE KALI..."
cat << 'KALINET' > /storage/scripts/kali_net_menu.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_kali
LOG_DIR="/storage/scripts/logs"
mkdir -p "$LOG_DIR"
sleep 0.2

while true; do
    dialog --clear --title " KALI NETWORK OPS " \
    --menu "Selecciona vector de ataque:" 0 0 0 \
    "1" "Ping Sweep (Clon Fing)" \
    "2" "Escaneo Agresivo (SO y Puertos)" \
    "3" "Escaneo Sigiloso (SYN Stealth)" \
    "4" "Conexion SSH (Lado A)" \
    "5" "Salir a Consola" 2> /tmp/kali_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/kali_opt.txt)

    case "$OPT" in
        "1")
            SUBNET=$(ip -o -f inet addr show | awk '/scope global/ {print $4}' | head -n 1)
            [ -z "$SUBNET" ] && SUBNET="192.168.1.0/24"
            FILE="$LOG_DIR/fing_scan_$(date +%Y%m%d_%H%M).log"
            clear
            echo "[+] Mapeo ARP en subred: $SUBNET"
            docker exec -it kali_core nmap -sn -PR "$SUBNET" | tee "$FILE"
            read pause
            ;;
        "2")
            dialog --clear --title " ESCANEO AGRESIVO " \
            --inputbox "IP Objetivo:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                FILE="$LOG_DIR/agresivo_${IP}_$(date +%H%M).log"
                clear
                echo "[+] Ataque ruidoso a $IP..."
                docker exec -it kali_core nmap -A -T4 "$IP" | tee "$FILE"
                read pause
            fi
            ;;
        "3")
            dialog --clear --title " ESCANEO SIGILOSO " \
            --inputbox "IP Objetivo:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                FILE="$LOG_DIR/stealth_${IP}_$(date +%H%M).log"
                clear
                echo "[+] Escaneo SYN Stealth a $IP..."
                docker exec -it kali_core nmap -sS -T4 "$IP" | tee "$FILE"
                read pause
            fi
            ;;
        "4")
            dialog --clear --title " SSH SECURE SHELL " \
            --inputbox "IP Destino:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                clear
                echo "[+] Conectando a $IP..."
                docker exec -it kali_core ssh "root@$IP"
                echo "Conexion cerrada. ENTER para volver."
                read pause
            fi
            ;;
        "5") break ;;
    esac
done
clear
/bin/sh
KALINET
chmod +x /storage/scripts/kali_net_menu.sh


echo "[*] 2. CREANDO MENU SETTINGS CON BACKUP INTELIGENTE..."
cat << 'SETTINGS' > /storage/scripts/settings_tmux.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main

while true; do
    dialog --clear --title " AJUSTES Y SEGURIDAD " \
    --menu "Opciones del sistema:" 0 0 0 \
    "1" "Backup del Sistema (Solo scripts y config)" \
    "2" "Volver al Menu Principal" 2> /tmp/set_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/set_opt.txt | tr -d '[:space:]')

    case "$OPT" in
        "1")
            clear
            echo "[*] Analizando archivos esenciales..."
            DEST_DIR="/storage/scripts/backup"
            mkdir -p "$DEST_DIR"
            FILE="$DEST_DIR/cyberdeck_core_$(date +%Y%m%d_%H%M).tar.gz"
            
            echo "[*] Comprimiendo el cerebro del CyberDeck..."
            echo "[!] (Ignorando contenedores Docker para ahorrar espacio)"
            
            # Magia de ingenieria: Guardamos todo pero EXCLUIMOS las carpetas pesadas
            tar --exclude='/storage/scripts/docker/data' \
                --exclude='/storage/scripts/docker/build_kali' \
                --exclude='/storage/scripts/backup' \
                --exclude='/storage/scripts/logs' \
                -czf "$FILE" \
                /storage/main_menu.sh \
                /storage/.dialogrc* \
                /storage/.tmux.conf \
                /storage/terminfo \
                /storage/scripts/
            
            if [ $? -eq 0 ]; then
                echo ""
                echo "[+] COPIA DE SEGURIDAD CREADA CON EXITO!"
                echo "[+] Ruta: $FILE"
                echo ""
                echo "Guarda este archivo (.tar.gz) en tu PC o pendrive."
                echo "Si algo se rompe, solo tendras que descomprimirlo en /"
            else
                echo "[-] Error al crear la copia de seguridad."
            fi
            
            echo ""
            echo "Pulsa ENTER (A) para volver..."
            read pause
            ;;
        "2")
            break
            ;;
    esac
done
clear
SETTINGS
chmod +x /storage/scripts/settings_tmux.sh

echo ">>> ACTUALIZACION APLICADA. Tu sistema ahora es auditable y seguro."
