#!/bin/sh

echo "[*] 1. RESTAURANDO TEMA OSCURO (NATIVO)..."
# Creamos el archivo EXACTO que pide tu main_menu.sh (/storage/.dialogrc)
cat << 'D_RC' > /storage/.dialogrc
use_shadow = ON
use_colors = ON
screen_color = (CYAN,BLACK,ON)
dialog_color = (CYAN,BLACK,OFF)
title_color = (WHITE,BLACK,ON)
border_color = (CYAN,BLACK,ON)
button_active_color = (WHITE,BLUE,ON)
button_inactive_color = (CYAN,BLACK,OFF)
item_color = (WHITE,BLACK,OFF)
item_selected_color = (WHITE,BLUE,ON)
tag_color = (CYAN,BLACK,ON)
tag_selected_color = (YELLOW,BLUE,ON)
D_RC

echo "[*] 2. RESTAURANDO MEDIDAS MILIMETRICAS DEL MENU..."
# Devolvemos las coordenadas 18 64 9 que venian en tu backup original
sed -i 's/--menu " SISTEMA CENTRAL " .*/--menu " SISTEMA CENTRAL " 18 64 9 \\/' /storage/main_menu.sh

# Ajustamos tambien el submenu de KALI si existe para que cuadre
if [ -f /storage/scripts/kali_net_menu.sh ]; then
    sed -i 's/--menu "Selecciona vector de ataque:" .*/--menu "Selecciona vector de ataque:" 18 64 9 \\/' /storage/scripts/kali_net_menu.sh
fi

# Ajustamos el submenu de SETTINGS
if [ -f /storage/scripts/settings_tmux.sh ]; then
    sed -i 's/--menu "Opciones del sistema:" .*/--menu "Opciones del sistema:" 18 64 9 \\/' /storage/scripts/settings_tmux.sh
fi

echo ">>> CIRUGIA COMPLETADA. Lanza el menu de nuevo."
