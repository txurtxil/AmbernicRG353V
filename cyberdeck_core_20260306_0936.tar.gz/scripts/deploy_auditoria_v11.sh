#!/bin/sh

echo "[*] 1. REPARANDO EL TECLADO (L1 y Y = Borrar)..."
sed -i '/backspace/d' /storage/scripts/keyb/universal.gptk 2>/dev/null
echo "y = backspace" >> /storage/scripts/keyb/universal.gptk
echo "l1 = backspace" >> /storage/scripts/keyb/universal.gptk
killall -9 gptokeyb 2>/dev/null
/usr/bin/gptokeyb "foot" -c "/storage/scripts/keyb/universal.gptk" &

echo "[*] 2. REPARANDO HTOP EN LA SHELL (Usando motor Kali)..."
cat << 'WARROOM' > /storage/scripts/start_war_room.sh
#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

/storage/scripts/bin/tmux kill-session -t war_room 2>/dev/null
sleep 0.5

if ! docker ps >/dev/null 2>&1; then
    /storage/scripts/start_docker_daemon.sh
    sleep 3
fi

# Levantamos el core de Kali si no esta, para usar su htop
if ! docker ps | grep -q kali_core; then
    docker run -d --rm --name kali_core --net=host --pid=host --privileged kali-cyberdeck:latest sleep infinity
fi

/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s war_room -n "Admin" "/bin/sh"

# Derecha: MC (En Kali)
/storage/scripts/bin/tmux split-window -h -t war_room:Admin "docker exec -it kali_core mc || /bin/sh"

# Izquierda Abajo: Htop REPARADO (Ejecutado a traves del motor de Kali para que se vea bien)
/storage/scripts/bin/tmux select-pane -t war_room:Admin.0
/storage/scripts/bin/tmux split-window -v -t war_room:Admin "docker exec -it kali_core htop || /bin/sh"

/storage/scripts/bin/tmux select-pane -t war_room:Admin.0
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room -n "SSH" "/storage/scripts/ssh_launcher.sh"
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room -n "Shell" "/bin/sh"

/storage/scripts/bin/tmux select-window -t war_room:Admin
/storage/scripts/bin/tmux attach-session -t war_room
clear
WARROOM
chmod +x /storage/scripts/start_war_room.sh

echo "[*] 3. CREANDO MENU DE HERRAMIENTAS LATERAL (SSH + IPERF3)..."
cat << 'KALITOOLS' > /storage/scripts/kali_tools_menu.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main
sleep 0.2

# Instalar iperf3 en background si no existe
docker exec kali_core bash -c "which iperf3 >/dev/null || (apt-get update && apt-get install -y iperf3)" >/dev/null 2>&1

while true; do
    dialog --clear --title " SYSADMIN TOOLS " \
    --menu "Herramientas de conexion:" 0 0 0 \
    "1" "Conexion SSH (Pre-config)" \
    "2" "Iperf3 (Modo Servidor)" \
    "3" "Iperf3 (Modo Cliente)" \
    "4" "Salir a Consola Libre" 2> /tmp/k_tools.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/k_tools.txt)

    case "$OPT" in
        "1")
            dialog --clear --title " SSH SECURE SHELL " \
            --inputbox "IP Destino:" 0 0 "192.168.1." 2> /tmp/k_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/k_ip.txt | tr -d '[:space:]')
                clear
                echo "[+] Conectando a $IP..."
                docker exec -it kali_core ssh "root@$IP"
                echo "Conexion cerrada. ENTER para volver."
                read pause
            fi
            ;;
        "2")
            clear
            echo "[+] Iniciando Servidor de Velocidad Iperf3..."
            echo "[+] Esperando conexiones de clientes..."
            docker exec -it kali_core iperf3 -s
            echo "Servidor detenido. ENTER para volver."
            read pause
            ;;
        "3")
            dialog --clear --title " IPERF3 CLIENTE " \
            --inputbox "IP del Servidor:" 0 0 "192.168.1." 2> /tmp/k_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/k_ip.txt | tr -d '[:space:]')
                clear
                echo "[+] Testeando ancho de banda hacia $IP..."
                docker exec -it kali_core iperf3 -c "$IP"
                echo "Test finalizado. ENTER para volver."
                read pause
            fi
            ;;
        "4") break ;;
    esac
done
clear
/bin/sh
KALITOOLS
chmod +x /storage/scripts/kali_tools_menu.sh

echo "[*] 4. AMPLIANDO MENU DE AUDITORIA DE RED (Centrado)..."
cat << 'KALINET' > /storage/scripts/kali_net_menu.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_kali
LOG_DIR="/storage/scripts/logs"
mkdir -p "$LOG_DIR"
sleep 0.2

while true; do
    # Usando 0 0 0 aseguramos el centrado perfecto
    dialog --clear --title " KALI NETWORK OPS " \
    --menu "Selecciona vector de ataque:" 0 0 0 \
    "1" "Ping Sweep (Clon Fing)" \
    "2" "Escaneo Agresivo (SO y Puertos)" \
    "3" "Escaneo Sigiloso (SYN Stealth)" \
    "4" "Salir a Consola" 2> /tmp/kali_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/kali_opt.txt)

    case "$OPT" in
        "1")
            SUBNET=$(ip -o -f inet addr show | awk '/scope global/ {print $4}' | head -n 1)
            [ -z "$SUBNET" ] && SUBNET="192.168.1.0/24"
            FILE="$LOG_DIR/fing_scan_$(date +%Y%m%d_%H%M).log"
            clear
            echo "[+] Mapeo ARP en subred: $SUBNET"
            docker exec -it kali_core nmap -sn -PR "$SUBNET" | tee "$FILE"
            read pause
            ;;
        "2")
            dialog --clear --title " ESCANEO AGRESIVO " \
            --inputbox "IP Objetivo:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                FILE="$LOG_DIR/agresivo_${IP}_$(date +%H%M).log"
                clear
                echo "[+] Ataque ruidoso a $IP..."
                docker exec -it kali_core nmap -A -T4 "$IP" | tee "$FILE"
                read pause
            fi
            ;;
        "3")
            dialog --clear --title " ESCANEO SIGILOSO " \
            --inputbox "IP Objetivo:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                FILE="$LOG_DIR/stealth_${IP}_$(date +%H%M).log"
                clear
                echo "[+] Escaneo SYN Stealth a $IP..."
                docker exec -it kali_core nmap -sS -T4 "$IP" | tee "$FILE"
                read pause
            fi
            ;;
        "4") break ;;
    esac
done
clear
/bin/sh
KALINET
chmod +x /storage/scripts/kali_net_menu.sh

echo "[*] 5. RECONSTRUYENDO PANELES DE KALI..."
cat << 'KALI' > /storage/scripts/start_kali_multitask.sh
#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

if ! docker ps | grep -q kali_core; then
    docker run -d --rm --name kali_core --net=host --pid=host --privileged kali-cyberdeck:latest sleep infinity
    sleep 3 
fi

/storage/scripts/bin/tmux kill-session -t kali_tactico 2>/dev/null
sleep 0.5

# Izquierda: Menu de Auditoria Centrado
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s kali_tactico "/storage/scripts/kali_net_menu.sh"

# Derecha Arriba: Monitor de red
/storage/scripts/bin/tmux split-window -h -t kali_tactico "docker exec -it kali_core watch -n 2 'netstat -tulnp | grep LISTEN'"

# Derecha Abajo: Menu SysAdmin (SSH + Iperf3)
/storage/scripts/bin/tmux select-pane -t kali_tactico:0.1
/storage/scripts/bin/tmux split-window -v -t kali_tactico "/storage/scripts/kali_tools_menu.sh"

/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux attach-session -t kali_tactico
clear
KALI
chmod +x /storage/scripts/start_kali_multitask.sh

echo ">>> ACTUALIZACION DE AUDITORIA COMPLETADA."
