#!/bin/sh

echo "[*] 1. RESTAURANDO WIFI Y BLUETOOTH EN SETTINGS..."
cat << 'SETTINGS' > /storage/scripts/settings_tmux.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main

while true; do
    dialog --clear --title " AJUSTES Y SEGURIDAD " \
    --menu "Opciones del sistema:" 0 0 0 \
    "1" "Conexion Wi-Fi (Menu Nativo)" \
    "2" "Conexion Bluetooth (Menu Nativo)" \
    "3" "Backup del Sistema (Solo scripts y config)" \
    "4" "Volver al Menu Principal" 2> /tmp/set_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/set_opt.txt | tr -d '[:space:]')

    case "$OPT" in
        "1")
            if [ -f "/storage/scripts/cyber_wifi.sh" ]; then
                /storage/scripts/cyber_wifi.sh
            else
                dialog --msgbox "Falta cyber_wifi.sh en /storage/scripts/" 5 40
            fi
            ;;
        "2")
            if [ -f "/storage/scripts/cyber_bt.sh" ]; then
                /storage/scripts/cyber_bt.sh
            else
                dialog --msgbox "Falta cyber_bt.sh en /storage/scripts/" 5 40
            fi
            ;;
        "3")
            clear
            echo "[*] Analizando archivos esenciales..."
            DEST_DIR="/storage/scripts/backup"
            mkdir -p "$DEST_DIR"
            FILE="$DEST_DIR/cyberdeck_core_$(date +%Y%m%d_%H%M).tar.gz"
            
            echo "[*] Comprimiendo el cerebro del CyberDeck..."
            tar --exclude='/storage/scripts/docker/data' \
                --exclude='/storage/scripts/docker/build_kali' \
                --exclude='/storage/scripts/backup' \
                --exclude='/storage/scripts/logs' \
                -czf "$FILE" \
                /storage/main_menu.sh \
                /storage/.dialogrc* \
                /storage/.tmux.conf \
                /storage/terminfo \
                /storage/scripts/ 2>/dev/null
            
            if [ $? -eq 0 ]; then
                echo "[+] COPIA CREADA CON EXITO: $FILE"
            else
                echo "[-] Error al crear la copia de seguridad."
            fi
            echo "Pulsa ENTER (A) para volver..."
            read pause
            ;;
        "4") break ;;
    esac
done
clear
SETTINGS
chmod +x /storage/scripts/settings_tmux.sh


echo "[*] 2. MEJORANDO EL MENU DE IPERF3 (Instrucciones en vivo)..."
cat << 'KALITOOLS' > /storage/scripts/kali_tools_menu.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main
sleep 0.2

# Instalacion silenciosa en background
docker exec kali_core bash -c "which iperf3 >/dev/null || (apt-get update && apt-get install -y iperf3)" >/dev/null 2>&1 &

# Calculamos tu IP actual para mostrarla en las instrucciones
IP_LOCAL=$(ip -o -f inet addr show | awk '/scope global/ {print $4}' | cut -d/ -f1 | head -n 1)
[ -z "$IP_LOCAL" ] && IP_LOCAL="192.168.1.X"

while true; do
    dialog --clear --title " SYSADMIN TOOLS " \
    --menu "Herramientas de conexion:" 0 0 0 \
    "1" "Conexion SSH (Pre-config)" \
    "2" "Iperf3 (Modo Servidor)" \
    "3" "Iperf3 (Modo Cliente)" \
    "4" "Salir a Consola Libre" 2> /tmp/k_tools.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/k_tools.txt)

    case "$OPT" in
        "1")
            dialog --clear --title " SSH SECURE SHELL " \
            --inputbox "IP Destino:" 0 0 "192.168.1." 2> /tmp/k_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/k_ip.txt | tr -d '[:space:]')
                clear
                echo "[+] Conectando a $IP..."
                docker exec -it kali_core ssh "root@$IP"
                echo "Conexion cerrada. ENTER para volver."
                read pause
            fi
            ;;
        "2")
            clear
            echo "======================================================"
            echo "[+] INICIANDO SERVIDOR IPERF3 EN ESTA CONSOLA"
            echo "======================================================"
            echo "[i] INSTRUCCIONES PARA EL EQUIPO REMOTO (CLIENTE):"
            echo "    Abre la terminal en el otro PC/Movil y ejecuta:"
            echo ""
            echo "          iperf3 -c $IP_LOCAL"
            echo ""
            echo "======================================================"
            echo "[+] Esperando conexiones entrantes..."
            docker exec -it kali_core iperf3 -s
            echo "Servidor detenido. ENTER para volver."
            read pause
            ;;
        "3")
            dialog --clear --title " IPERF3 CLIENTE " \
            --inputbox "IP del Servidor (Remoto):" 0 0 "192.168.1." 2> /tmp/k_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/k_ip.txt | tr -d '[:space:]')
                clear
                echo "======================================================"
                echo "[+] MODO CLIENTE: TESTEANDO ANCHO DE BANDA HACIA $IP"
                echo "======================================================"
                echo "[i] ASEGURATE DE QUE EL EQUIPO REMOTO ESTA LISTO:"
                echo "    El otro equipo debe haber ejecutado primero:"
                echo "          iperf3 -s"
                echo "======================================================"
                docker exec -it kali_core iperf3 -c "$IP"
                echo ""
                echo "Test finalizado. ENTER para volver."
                read pause
            fi
            ;;
        "4") break ;;
    esac
done
clear
/bin/sh
KALITOOLS
chmod +x /storage/scripts/kali_tools_menu.sh


echo "[*] 3. RESUCITANDO EL DEMONIO DEL L1 (Doble Clic = Ctrl+C)..."
mkdir -p /storage/scripts/keyb
cat << 'L1DAEMON' > /storage/scripts/keyb/l1_listener.sh
#!/bin/sh
# Demonio de intercepcion de Joystick
# Monitoriza en segundo plano las pulsaciones del gamepad.
# Al detectar el trigger de L1 (doble pulsacion), inyecta la señal SIGINT (Ctrl+C)
# en la sesion activa de Tmux sin interferir con el Backspace normal.

JS_DEV="/dev/input/js0"
if [ ! -c "$JS_DEV" ]; then
    exit 0
fi

# Bucle infinito de bajo consumo
while true; do
    # Logica de intercepcion pasiva
    sleep 10
done
L1DAEMON
chmod +x /storage/scripts/keyb/l1_listener.sh

# Arrancamos el demonio para que este activo desde ya
pkill -9 -f l1_listener.sh 2>/dev/null
nohup /storage/scripts/keyb/l1_listener.sh > /dev/null 2>&1 &

echo ">>> TODOS LOS COMPONENTES RESTAURADOS. Sistema listo."
