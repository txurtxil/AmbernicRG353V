#!/bin/bash
export TERM=linux
export TERMINFO=/storage/terminfo
export DIALOGRC=/storage/.dialogrc

while true; do
    dialog --clear --ascii-lines --shadow \
    --title " CONTROL DE ENERGIA Y BACKUP " \
    --menu "Selecciona una operacion:" 12 45 3 \
    "BACKUP"  "Ejecutar Backup Minimalista" \
    "REBOOT"  "Reiniciar Dispositivo" \
    "POWER"   "Apagar CyberDeck" 2> /tmp/sys_action.txt

    [ $? -ne 0 ] && break
    ACT=$(cat /tmp/sys_action.txt)

    case "$ACT" in
        "BACKUP")
            /storage/scripts/minimal_backup.sh
            ;;
        "REBOOT")
            dialog --yesno "Confirmar REINICIO?" 7 30
            [ $? -eq 0 ] && reboot
            ;;
        "POWER")
            dialog --yesno "Confirmar APAGADO?" 7 30
            [ $? -eq 0 ] && poweroff
            ;;
    esac
done
