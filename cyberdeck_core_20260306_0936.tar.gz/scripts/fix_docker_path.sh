#!/bin/bash

echo "[*] 1. CREANDO PUENTES PARA LOS TRABAJADORES DE DOCKER..."
# Vinculamos TODOS los binarios (containerd, runc, ctr, etc.) al sistema global
for bin in /storage/scripts/docker/bin/*; do
    nombre=$(basename "$bin")
    ln -sf "$bin" "/usr/local/bin/$nombre"
    ln -sf "$bin" "/usr/bin/$nombre" 2>/dev/null
done

echo "[*] 2. BLINDANDO EL SCRIPT DE ARRANQUE..."
# Inyectamos el PATH directamente en el demonio por si acaso
if ! grep -q "export PATH=" /storage/scripts/start_docker_daemon.sh; then
    sed -i '2i export PATH=$PATH:/storage/scripts/docker/bin:/usr/local/bin:/usr/bin' /storage/scripts/start_docker_daemon.sh
fi

echo "[*] 3. REINICIANDO MOTOR DOCKER..."
/storage/scripts/start_docker_daemon.sh
sleep 4

echo "=== ESTADO ACTUAL DEL LOG ==="
tail -n 6 /storage/scripts/docker/dockerd.log
echo "============================="

# Test final
if /storage/scripts/docker/bin/docker -H unix:///storage/scripts/docker/run/docker.sock ps > /dev/null 2>&1; then
    echo ">>> [+] ¡BINGO! El motor está en línea y funcionando."
else
    echo ">>> [-] Algo sigue bloqueando. Pásame el log que ha salido arriba."
fi
