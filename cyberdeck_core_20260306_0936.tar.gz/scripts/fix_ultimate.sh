#!/bin/sh

echo "[*] 1. Eliminando el fondo azul (Restaurando colores nativos)..."
rm -f /storage/.dialogrc_main
rm -f /storage/.dialogrc_kali

echo "[*] 2. Obligando a dialog a estirarse a los bordes..."
# Usamos las variables $LINES y $COLUMNS del sistema en lugar de 0 0 0
sed -i 's/--menu "SELECCIONA MODULO".*/--menu "SELECCIONA MODULO" ${LINES:-50} ${COLUMNS:-150} 20 \\/' /storage/main_menu.sh

if [ -f /storage/scripts/settings_tmux.sh ]; then
    sed -i 's/--menu "Opciones del sistema:".*/--menu "Opciones del sistema:" ${LINES:-50} ${COLUMNS:-150} 20 \\/' /storage/scripts/settings_tmux.sh
fi

if [ -f /storage/scripts/kali_net_menu.sh ]; then
    sed -i 's/--menu "Selecciona vector de ataque:".*/--menu "Selecciona vector de ataque:" ${LINES:-50} ${COLUMNS:-150} 20 \\/' /storage/scripts/kali_net_menu.sh
fi

echo ">>> SISTEMA PURGADO. Vuelve a lanzar el menu."
