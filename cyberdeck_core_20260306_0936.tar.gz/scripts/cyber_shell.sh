#!/bin/sh
export TERMINFO=/usr/share/terminfo
export TERM=linux
export XDG_RUNTIME_DIR=/tmp/xdg
export WAYLAND_DISPLAY=wayland-1

# Activar botones
pkill -9 -f input_daemon.sh
/storage/scripts/input_daemon.sh > /dev/null 2>&1 &

# Lanzar Tmux
/storage/scripts/bin/tmux new-session -A -s cyberdeck
