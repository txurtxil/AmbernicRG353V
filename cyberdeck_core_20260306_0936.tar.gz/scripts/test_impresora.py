#!/usr/bin/env python3
import socket
import sys

if len(sys.argv) < 2:
    print("Uso: python3 test_impresora.py <MAC_DE_LA_IMPRESORA>")
    sys.exit(1)

mac = sys.argv[1]
port = 1  # Canal 1 suele ser SPP (Serial Port Profile)

print(f"[*] Iniciando Bypass de Kernel hacia: {mac} (Canal {port})...")

try:
    # Creamos un socket Bluetooth crudo
    s = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM)
    s.connect((mac, port))
    
    # Inyectamos el ticket en bytes puros
    ticket = "\n======================\n  CYBERDECK WAR-ROOM  \n======================\nBYPASS KERNEL: EXITOSO\nStatus: HACKED\n======================\n\n\n"
    s.send(ticket.encode('utf-8'))
    
    s.close()
    print("[+] Datos enviados. ¡Revisa la impresora!")
except Exception as e:
    print(f"[-] El bypass fracasó: {e}")
