#!/bin/bash
EVENT_ID=$(grep -A 4 'Name="retrogame_joypad"' /proc/bus/input/devices | grep -o 'event[0-9]\+' | head -n 1)
LAST_TIME=0

evtest "/dev/input/$EVENT_ID" | grep --line-buffered "code 310 (BTN_TL), value 1" | while read -r line; do
    CURRENT_TIME=$(date +%s%3N)
    DIFF=$((CURRENT_TIME - LAST_TIME))
    
    if [ $DIFF -le 400 ]; then
        # Doble clic -> Ctrl+C
        pkill -9 -f wvkbd
        /storage/scripts/bin/tmux send-keys C-c 2>/dev/null
        LAST_TIME=0
    else
        # Clic simple -> Teclado
        /storage/scripts/keyb/toggle_osk.sh &
        LAST_TIME=$CURRENT_TIME
    fi
done
