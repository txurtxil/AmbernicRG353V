#!/bin/bash
if pgrep -f "wvkbd" > /dev/null; then
    pkill -9 -f wvkbd
else
    /storage/scripts/keyb/osk_daemon.sh &
fi
