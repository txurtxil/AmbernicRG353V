#!/bin/sh

echo "[*] 1. FULMINANDO EL DEMONIO L1..."
# Matamos el proceso en segundo plano que esta secuestrando el boton
pkill -9 -f l1_listener.sh 2>/dev/null
# Borramos el archivo para que no vuelva a molestar
rm -f /storage/scripts/keyb/l1_listener.sh 2>/dev/null

echo "[*] 2. LIMPIANDO EL MENU PRINCIPAL..."
# Quitamos las lineas del main_menu.sh que intentaban arrancar el demonio
sed -i '/l1_listener.sh/d' /storage/main_menu.sh 2>/dev/null

echo "[*] 3. PURGANDO EL MAPEO DEL MANDO..."
# Aseguramos que no quede ninguna regla 'l1=' huerfana en tu configuracion
sed -i '/l1 =/d' /storage/scripts/keyb/universal.gptk 2>/dev/null
sed -i '/l1=/d' /storage/scripts/keyb/universal.gptk 2>/dev/null

echo "[*] 4. REINICIANDO DRIVER DEL MANDO..."
# Reiniciamos gptokeyb para que suelte el joystick y lea la configuracion limpia
killall -9 gptokeyb 2>/dev/null
/usr/bin/gptokeyb "foot" -c "/storage/scripts/keyb/universal.gptk" &

echo ">>> EMERGENCIA RESUELTA. El boton L1 ha sido devuelto al sistema."
