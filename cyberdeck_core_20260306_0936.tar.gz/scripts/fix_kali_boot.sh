#!/bin/sh

echo "[*] 1. REPARANDO EL DESPERTADOR DE DOCKER EN KALI..."
cat << 'KALI' > /storage/scripts/start_kali_multitask.sh
#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

# EL PUENTE HACIA EL MOTOR (Esto arregla el fallo del primer arranque)
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

# Despertador de Docker (Misma logica blindada de la Shell)
if ! docker ps >/dev/null 2>&1; then
    echo "[*] Despertando motor Docker..."
    /storage/scripts/start_docker_daemon.sh
    sleep 3
fi

# Levantamos el contenedor de Kali
if ! docker ps | grep -q kali_core; then
    echo "[*] Levantando nucleo tactico..."
    docker run -d --rm --name kali_core --net=host --pid=host --privileged kali-cyberdeck:latest sleep infinity
    sleep 3 
fi

/storage/scripts/bin/tmux kill-session -t kali_tactico 2>/dev/null
sleep 0.5

# Izquierda: Menu de Auditoria Centrado
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s kali_tactico "/storage/scripts/kali_net_menu.sh"

# Derecha Arriba: Monitor de red
/storage/scripts/bin/tmux split-window -h -t kali_tactico "docker exec -it kali_core watch -n 2 'netstat -tulnp | grep LISTEN'"

# Derecha Abajo: Menu SysAdmin (SSH + Iperf3)
/storage/scripts/bin/tmux select-pane -t kali_tactico:0.1
/storage/scripts/bin/tmux split-window -v -t kali_tactico "/storage/scripts/kali_tools_menu.sh"

/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux attach-session -t kali_tactico
clear
KALI
chmod +x /storage/scripts/start_kali_multitask.sh


echo "[*] 2. ACELERANDO EL MENU SYSADMIN (Procesos en segundo plano)..."
cat << 'KALITOOLS' > /storage/scripts/kali_tools_menu.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main
sleep 0.2

# Instalar iperf3 en background SIN BLOQUEAR EL MENU (el '&' final es la magia)
docker exec kali_core bash -c "which iperf3 >/dev/null || (apt-get update && apt-get install -y iperf3)" >/dev/null 2>&1 &

while true; do
    dialog --clear --title " SYSADMIN TOOLS " \
    --menu "Herramientas de conexion:" 0 0 0 \
    "1" "Conexion SSH (Pre-config)" \
    "2" "Iperf3 (Modo Servidor)" \
    "3" "Iperf3 (Modo Cliente)" \
    "4" "Salir a Consola Libre" 2> /tmp/k_tools.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/k_tools.txt)

    case "$OPT" in
        "1")
            dialog --clear --title " SSH SECURE SHELL " \
            --inputbox "IP Destino:" 0 0 "192.168.1." 2> /tmp/k_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/k_ip.txt | tr -d '[:space:]')
                clear
                echo "[+] Conectando a $IP..."
                docker exec -it kali_core ssh "root@$IP"
                echo "Conexion cerrada. ENTER para volver."
                read pause
            fi
            ;;
        "2")
            clear
            echo "[+] Iniciando Servidor de Velocidad Iperf3..."
            echo "[+] Esperando conexiones de clientes..."
            docker exec -it kali_core iperf3 -s
            echo "Servidor detenido. ENTER para volver."
            read pause
            ;;
        "3")
            dialog --clear --title " IPERF3 CLIENTE " \
            --inputbox "IP del Servidor:" 0 0 "192.168.1." 2> /tmp/k_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/k_ip.txt | tr -d '[:space:]')
                clear
                echo "[+] Testeando ancho de banda hacia $IP..."
                docker exec -it kali_core iperf3 -c "$IP"
                echo "Test finalizado. ENTER para volver."
                read pause
            fi
            ;;
        "4") break ;;
    esac
done
clear
/bin/sh
KALITOOLS
chmod +x /storage/scripts/kali_tools_menu.sh

echo ">>> OPTIMIZACION TERMINADA. La War-Room Ofensiva vuela."
