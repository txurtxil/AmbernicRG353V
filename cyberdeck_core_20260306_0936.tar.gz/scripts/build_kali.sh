#!/bin/bash
# =================================================================
#  CYBERDECK: CONSTRUCTOR DE KALI LINUX (FIX DE RED APLICADO)
# =================================================================

DOCKER_BIN="/storage/scripts/docker/bin/docker"
BUILD_DIR="/storage/scripts/docker/build_kali"

echo "[*] 1. PREPARANDO ENTORNO DE CONSTRUCCIÓN..."
mkdir -p $BUILD_DIR
cd $BUILD_DIR

cat << 'DOCKERFILE' > Dockerfile
FROM kalilinux/kali-rolling:latest

ENV DEBIAN_FRONTEND=noninteractive

# Instalamos el core y herramientas tácticas básicas
RUN apt-get update && apt-get install -y --no-install-recommends \
    nmap \
    net-tools \
    iproute2 \
    iputils-ping \
    mc \
    nano \
    tmux \
    htop \
    curl \
    wget \
    && apt-get clean \
    && rm -rf /var/lib/apt/lists/*

CMD ["/bin/bash"]
DOCKERFILE

echo "[*] 2. DESCARGANDO Y CONSTRUYENDO IMAGEN..."
# EL FIX DE RED: Añadimos --network=host para que el instalador tenga internet
$DOCKER_BIN -H unix:///storage/scripts/docker/run/docker.sock build --network=host -t kali-cyberdeck:latest .

if [ $? -eq 0 ]; then
    echo ">>> [!] ÉXITO: Imagen kali-cyberdeck:latest creada."
else
    echo ">>> [-] ERROR: Falló la construcción."
fi
