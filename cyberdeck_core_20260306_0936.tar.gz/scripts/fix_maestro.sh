#!/bin/bash

echo "[*] 1. REPARANDO SHELL (Restaurando Tabs/Pestañas y blindando Tmux)..."
cat << 'WARROOM' > /storage/scripts/start_war_room.sh
#!/bin/bash
export TERMINFO=/storage/terminfo
export TERM=linux
# Forzamos idioma base para evitar el colapso del "server exited"
export LC_ALL=C
export LANG=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

# Limpiamos cualquier sesión fantasma previa
/storage/scripts/bin/tmux kill-session -t war_room 2>/dev/null

# Creamos la sesión principal y 2 pestañas adicionales (Tus Tabs)
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s war_room -n "Main" "/bin/bash"
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room:1 -n "Net" "/bin/bash"
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room:2 -n "Logs" "/bin/bash"

# Nos enfocamos en la primera pestaña y entramos
/storage/scripts/bin/tmux select-window -t war_room:0
/storage/scripts/bin/tmux attach-session -t war_room || {
    echo "======================================"
    echo "[!] TMUX HA FALLADO EN LA SHELL"
    echo "======================================"
    sleep 10
}
WARROOM
chmod +x /storage/scripts/start_war_room.sh

echo "[*] 2. REPARANDO KALI (Inyectando el puente de Docker que faltaba)..."
cat << 'KALI' > /storage/scripts/start_kali_multitask.sh
#!/bin/bash
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export LANG=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

# ¡EL SECRETO QUE FALTABA PARA QUE ENCUENTRE DOCKER!
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

# 1. Comprobamos si el motor Docker está vivo
if ! docker ps >/dev/null 2>&1; then
    echo "[!] Docker dormido. Despertando el motor..."
    /storage/scripts/start_docker_daemon.sh
    sleep 4
    if ! docker ps >/dev/null 2>&1; then
        echo "[!] ERROR GRAVE: Docker sigue sin responder."
        sleep 10
        exit 1
    fi
fi

# 2. Encendemos el núcleo de Kali
if ! docker ps | grep -q kali_core; then
    echo "[*] Levantando núcleo de Kali (Por favor espera 3 segundos)..."
    docker run -d --rm --name kali_core --net=host --privileged kali-cyberdeck:latest sleep infinity
    sleep 3 
fi

# 3. Lanzamos el entorno multipanel
/storage/scripts/bin/tmux kill-session -t kali_tactico 2>/dev/null
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s kali_tactico "docker exec -it kali_core /bin/bash"
/storage/scripts/bin/tmux split-window -h -t kali_tactico "docker exec -it kali_core watch -n 2 'netstat -tulnp | grep LISTEN'"
/storage/scripts/bin/tmux split-window -v -t kali_tactico "docker exec -it kali_core htop"
/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux split-window -v -t kali_tactico "docker exec -it kali_core /bin/bash"

/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux attach-session -t kali_tactico || {
    echo "[!] TMUX HA FALLADO AL MOSTRAR KALI."
    sleep 10
}
KALI
chmod +x /storage/scripts/start_kali_multitask.sh

echo "[*] 3. REGENERANDO MENÚ PRINCIPAL LIMPIO (Para frenar GTOP)..."
cat << 'MENU' > /storage/main_menu.sh
#!/bin/sh
export LC_ALL=C
export LANG=C
export TERM=linux
export TERMINFO=/storage/terminfo

export DOCKER="/storage/scripts/docker/bin/docker"
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

modprobe joydev 2>/dev/null
modprobe uinput 2>/dev/null
chmod 666 /dev/uinput 2>/dev/null

killall -9 gptokeyb 2>/dev/null
pkill -9 -f l1_listener.sh 2>/dev/null
export SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1
export SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1

/usr/bin/gptokeyb "foot" -c "/storage/scripts/keyb/universal.gptk" &
nohup /storage/scripts/keyb/l1_listener.sh > /dev/null 2>&1 &

get_stats() {
    IP=$(ip route get 1 2>/dev/null | awk '{print $7;exit}' || echo "OFFLINE")
    BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "??")
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null | awk '{print int($1/1000)}')
    echo "[ IP: $IP | BAT: $BAT% | TEMP: $TEMP'C ]"
}

while true; do
    INFO=$(get_stats)
    export DIALOGRC=/storage/.dialogrc_main
    
    dialog --timeout 60 --ascii-lines --shadow --clear \
    --backtitle "CyberDeck OS - SISTEMA CENTRAL" \
    --title " $INFO " \
    --menu "SELECCIONA MÓDULO" 18 64 8 \
    "SHELL"    "Terminal Principal (Con Tabs)" \
    "DEV"      "Entorno de Desarrollo" \
    "GTOP"     "Monitor de Sistema (Gtop)" \
    "KALI"     "Suite Ofensiva Kali (Multitarea)" \
    "SETTINGS" "Ajustes del Sistema" \
    "EXIT"     "Salir a Terminal Plana" 2> /tmp/choice.txt
    
    [ $? -ne 0 ] && continue
    CHOICE=$(cat /tmp/choice.txt | tr -d '[:space:]')
    clear
    
    case "$CHOICE" in
        "SHELL") /storage/scripts/start_war_room.sh ;;
        "DEV") /storage/scripts/submenu_desarrollo.sh ;;
        "GTOP") 
            # El freno mágico para GTOP
            /storage/scripts/bin/tmux new-session -A -s gtop "bash -c 'gtop --utf-force || { echo \"==================\"; echo \"[!] GTOP HA FALLADO\"; echo \"Lee el error arriba.\"; echo \"==================\"; sleep 10; }'" 
            ;;
        "KALI") 
            export DIALOGRC=/storage/.dialogrc_kali
            dialog --msgbox "Desplegando entorno táctico de Kali..." 5 45
            /storage/scripts/start_kali_multitask.sh 
            ;;
        "SETTINGS") /storage/scripts/settings_tmux.sh ;;
        "EXIT") break ;;
    esac
done
MENU
chmod +x /storage/main_menu.sh

echo ">>> REPARACIÓN FINALIZADA. Lanza el menú principal."
