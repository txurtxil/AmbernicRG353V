#!/bin/bash

echo "[*] 1. REPARANDO TABS DE LA SHELL (Modo Auto-Índice a prueba de fallos)..."
cat << 'WARROOM' > /storage/scripts/start_war_room.sh
#!/bin/bash
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export LANG=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

# Limpiamos sesiones fantasmas
/storage/scripts/bin/tmux kill-session -t war_room 2>/dev/null

# Creamos la sesión y los Tabs SIN forzar el número de ventana
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s war_room -n "Main"
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room -n "Net"
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room -n "Logs"

# Entramos directamente a la sesión (Tmux nos dejará en la última pestaña abierta o en Main)
/storage/scripts/bin/tmux attach-session -t war_room || {
    echo "======================================"
    echo "[!] TMUX HA FALLADO AL ABRIR LA SHELL"
    echo "======================================"
    sleep 5
}
WARROOM
chmod +x /storage/scripts/start_war_room.sh

echo "[*] 2. LIMPIANDO EL COMANDO DE GTOP EN EL MENÚ PRINCIPAL..."
# Cambiamos la subshell problemática por el comando directo que pediste
sed -i 's|"bash -c.*"|"gtop --utf-force"|g' /storage/main_menu.sh

echo ">>> ARREGLO APLICADO. Docker ni se ha enterado."
