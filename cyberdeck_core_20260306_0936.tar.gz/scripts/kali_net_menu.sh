#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_kali
LOG_DIR="/storage/scripts/logs"
mkdir -p "$LOG_DIR"
sleep 0.2

while true; do
    dialog --clear --title " KALI NETWORK OPS " \
    --menu "Selecciona vector de ataque:" 18 64 9 \
    "1" "Ping Sweep (Clon Fing)" \
    "2" "Escaneo Agresivo (SO y Puertos)" \
    "3" "Escaneo Sigiloso (SYN Stealth)" \
    "4" "Conexion SSH (Lado A)" \
    "5" "Salir a Consola" 2> /tmp/kali_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/kali_opt.txt)

    case "$OPT" in
        "1")
            SUBNET=$(ip -o -f inet addr show | awk '/scope global/ {print $4}' | head -n 1)
            [ -z "$SUBNET" ] && SUBNET="192.168.1.0/24"
            FILE="$LOG_DIR/fing_scan_$(date +%Y%m%d_%H%M).log"
            clear
            echo "[+] Mapeo ARP en subred: $SUBNET"
            docker exec -it kali_core nmap -sn -PR "$SUBNET" | tee "$FILE"
            read pause
            ;;
        "2")
            dialog --clear --title " ESCANEO AGRESIVO " \
            --inputbox "IP Objetivo:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                FILE="$LOG_DIR/agresivo_${IP}_$(date +%H%M).log"
                clear
                echo "[+] Ataque ruidoso a $IP..."
                docker exec -it kali_core nmap -A -T4 "$IP" | tee "$FILE"
                read pause
            fi
            ;;
        "3")
            dialog --clear --title " ESCANEO SIGILOSO " \
            --inputbox "IP Objetivo:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                FILE="$LOG_DIR/stealth_${IP}_$(date +%H%M).log"
                clear
                echo "[+] Escaneo SYN Stealth a $IP..."
                docker exec -it kali_core nmap -sS -T4 "$IP" | tee "$FILE"
                read pause
            fi
            ;;
        "4")
            dialog --clear --title " SSH SECURE SHELL " \
            --inputbox "IP Destino:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                clear
                echo "[+] Conectando a $IP..."
                docker exec -it kali_core ssh "root@$IP"
                echo "Conexion cerrada. ENTER para volver."
                read pause
            fi
            ;;
        "5") break ;;
    esac
done
clear
/bin/sh
