#!/bin/bash
# 1. Le decimos que los binarios están aquí (Soluciona el Read-Only)
export PATH=/storage/scripts/docker/bin:$PATH
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

# Matar procesos colgados
pkill -9 -f dockerd 2>/dev/null
pkill -9 -f containerd 2>/dev/null
sleep 1

echo "[+] Levantando motor Docker optimizado..."
# 2. Añadimos --iptables=false y --bridge=none (Soluciona el fallo de MASQUERADE)
nohup /storage/scripts/docker/bin/dockerd \
    --data-root /storage/scripts/docker/data \
    --host unix:///storage/scripts/docker/run/docker.sock \
    --pidfile /storage/scripts/docker/run/docker.pid \
    --exec-root /storage/scripts/docker/run/exec \
    --iptables=false \
    --bridge=none \
    > /storage/scripts/docker/dockerd.log 2>&1 &
