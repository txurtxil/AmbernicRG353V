#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export DIALOGRC=/storage/.dialogrc
DOCKER="/storage/docker/bin/docker"

mkdir -p /storage/kali/logs

while true; do
    dialog --clear --shadow --title " RADAR DE RED (NMAP) " \
    --menu "Selecciona vector de escaneo:" 16 58 7 \
    "1" "Ping Sweep (Descubrir IPs en red)" \
    "2" "Escaneo Profundo (OS, Servicios y Versiones)" \
    "3" "Escaneo de Puertos Especificos" \
    "4" "Motor de Vulnerabilidades (Nmap Vuln Scripts)" \
    "5" "ARP Scan (Descubrimiento MACs Local ultra-rapido)" \
    "6" "WHOIS (Reconocimiento de Dominios Publicos)" \
    "7" "--> Abrir Consola Libre de Kali" \
    "0" "<-- Salir de esta ventana" 2> /tmp/r_opt.txt
    
    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/r_opt.txt)
    
    case "$OPT" in
        1) dialog --inputbox "Subred a escanear:" 8 40 "192.168.1.0/24" 2> /tmp/ip.txt
           [ $? -eq 0 ] && { clear; LOG="/storage/kali/logs/nmap_pingsweep_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host kali-cyberdeck:latest nmap -sn $(cat /tmp/ip.txt) 2>&1 | tee "$LOG"; } ;;
        2) dialog --inputbox "IP Objetivo (Ej: 192.168.1.50):" 8 40 "192.168.1." 2> /tmp/ip.txt
           [ $? -eq 0 ] && { clear; LOG="/storage/kali/logs/nmap_profundo_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host kali-cyberdeck:latest nmap -A -T4 $(cat /tmp/ip.txt) 2>&1 | tee "$LOG"; } ;;
        3) dialog --inputbox "IP Objetivo:" 8 40 "192.168.1." 2> /tmp/ip.txt
           [ $? -eq 0 ] && { IP_T=$(cat /tmp/ip.txt); dialog --inputbox "Puertos a escanear:" 8 40 "80,443,8080,21,22" 2> /tmp/ports.txt; [ $? -eq 0 ] && { clear; LOG="/storage/kali/logs/nmap_puertos_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host kali-cyberdeck:latest nmap -p $(cat /tmp/ports.txt) $IP_T 2>&1 | tee "$LOG"; } } ;;
        4) dialog --inputbox "IP a auditar vulnerabilidades:" 8 40 "192.168.1." 2> /tmp/ip.txt
           [ $? -eq 0 ] && { clear; LOG="/storage/kali/logs/nmap_vuln_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host kali-cyberdeck:latest nmap --script vuln $(cat /tmp/ip.txt) 2>&1 | tee "$LOG"; } ;;
        5) clear; LOG="/storage/kali/logs/arp_scan_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host --privileged kali-cyberdeck:latest /bin/bash -c "arp-scan -l || echo 'Instala: apt install arp-scan -y'" 2>&1 | tee "$LOG" ;;
        6) dialog --inputbox "Dominio (Ej: google.com):" 8 40 "" 2> /tmp/domain.txt
           [ $? -eq 0 ] && { clear; LOG="/storage/kali/logs/whois_$(cat /tmp/domain.txt)_$(date +%Y%m%d).log"; $DOCKER run -it --rm --net=host kali-cyberdeck:latest /bin/bash -c "whois $(cat /tmp/domain.txt) || echo 'Instala: apt install whois -y'" 2>&1 | tee "$LOG"; } ;;
        7) clear; $DOCKER run -it --rm --net=host --privileged kali-cyberdeck:latest /bin/bash ;;
        0) break ;;
    esac
    echo -e "\n\033[1;33m[ Pulsa ENTER para volver al menu de Reconocimiento ]\033[0m"
    read dummy
done
