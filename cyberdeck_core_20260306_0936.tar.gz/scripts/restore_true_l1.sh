#!/bin/bash

echo "[*] 1. RESTAURANDO CONTROLADOR DE TECLADO (toggle_osk.sh)..."
cat << 'TOGGLE' > /storage/scripts/keyb/toggle_osk.sh
#!/bin/bash
if pgrep -f "wvkbd" > /dev/null; then
    pkill -9 -f wvkbd
else
    /storage/scripts/keyb/osk_daemon.sh &
fi
TOGGLE
chmod +x /storage/scripts/keyb/toggle_osk.sh

echo "[*] 2. RESTAURANDO DEMONIO WAYLAND (osk_daemon.sh)..."
cat << 'OSKDAEMON' > /storage/scripts/keyb/osk_daemon.sh
#!/bin/bash
export XDG_RUNTIME_DIR=/tmp/xdg
mkdir -p /tmp/xdg
chmod 700 /tmp/xdg
[ -e /tmp/xdg/wayland-0 ] && export WAYLAND_DISPLAY=wayland-0 || export WAYLAND_DISPLAY=wayland-1

killall -9 wvkbd 2>/dev/null
sleep 0.1
# wvkbd limpio, sin parametros que causen error de Wayland
/storage/scripts/keyb/wvkbd &
OSKDAEMON
chmod +x /storage/scripts/keyb/osk_daemon.sh

echo "[*] 3. RESTAURANDO EL CEREBRO DEL L1 (Clic y Doble Clic)..."
cat << 'LISTENER' > /storage/scripts/keyb/l1_listener.sh
#!/bin/bash
EVENT_ID=$(grep -A 4 'Name="retrogame_joypad"' /proc/bus/input/devices | grep -o 'event[0-9]\+' | head -n 1)
LAST_TIME=0

evtest "/dev/input/$EVENT_ID" | grep --line-buffered "code 310 (BTN_TL), value 1" | while read -r line; do
    CURRENT_TIME=$(date +%s%3N)
    DIFF=$((CURRENT_TIME - LAST_TIME))
    
    if [ $DIFF -le 400 ]; then
        # Doble clic -> Ctrl+C
        pkill -9 -f wvkbd
        /storage/scripts/bin/tmux send-keys C-c 2>/dev/null
        LAST_TIME=0
    else
        # Clic simple -> Teclado
        /storage/scripts/keyb/toggle_osk.sh &
        LAST_TIME=$CURRENT_TIME
    fi
done
LISTENER
chmod +x /storage/scripts/keyb/l1_listener.sh

echo "[*] 4. RESTAURANDO MAPEO ORIGINAL DEL MANDO..."
sed -i '/l1/d' /storage/scripts/keyb/universal.gptk 2>/dev/null
# Tu configuracion original dictaba f7 para L1
echo "l1 = f7" >> /storage/scripts/keyb/universal.gptk

killall -9 gptokeyb 2>/dev/null
/usr/bin/gptokeyb "foot" -c "/storage/scripts/keyb/universal.gptk" &

echo "[*] 5. REINICIANDO EL MOTOR DE INTERCEPCIÓN..."
pkill -9 -f l1_listener.sh 2>/dev/null
nohup /storage/scripts/keyb/l1_listener.sh > /dev/null 2>&1 &

# Nos aseguramos de que el menu principal siempre lo arranque en el futuro
if ! grep -q "l1_listener.sh" /storage/main_menu.sh; then
    sed -i '/gptokeyb/a nohup /storage/scripts/keyb/l1_listener.sh > /dev/null 2>&1 &' /storage/main_menu.sh
fi

echo ">>> MILAGRO COMPLETADO. El teclado y el Ctrl+C han vuelto a la vida."
