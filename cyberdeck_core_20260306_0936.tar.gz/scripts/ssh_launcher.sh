#!/bin/sh
export TERM=linux
export TERMINFO=/storage/terminfo
export LC_ALL=C
export LANG=C
export DIALOGRC=/storage/.dialogrc_main

# Pausa milimetrica para que Tmux asiente las dimensiones de la pestaña
sleep 0.2
clear

# Usar '0 0' en lugar de '8 40' obliga a dialog a calcular el centro exacto
dialog --clear --title " CONEXION SSH RAPIDA " \
--inputbox "Introduce la IP de destino:" 0 0 "192.168.1." 2> /tmp/ssh_ip.txt

if [ $? -eq 0 ]; then
    IP=$(cat /tmp/ssh_ip.txt | tr -d '[:space:]')
    clear
    echo "[+] Conectando por SSH a root@$IP..."
    ssh "root@$IP"
fi

clear
echo "[!] Conexion SSH finalizada o cancelada. Modo local."
/bin/sh
