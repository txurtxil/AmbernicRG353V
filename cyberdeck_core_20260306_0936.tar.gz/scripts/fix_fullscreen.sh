#!/bin/sh

# 1. Quitar los margenes del diseño visual
cat << 'D_RC' > /storage/.dialogrc_main
use_shadow = OFF
use_colors = ON
screen_color = (CYAN,BLUE,ON)
dialog_color = (BLACK,WHITE,OFF)
title_color = (BLUE,WHITE,ON)
border_color = (WHITE,WHITE,ON)
button_active_color = (WHITE,BLUE,ON)
button_inactive_color = (BLACK,WHITE,OFF)
margin_x = 0
margin_y = 0
D_RC
cp /storage/.dialogrc_main /storage/.dialogrc_kali 2>/dev/null

# 2. Forzar auto-escalado (0 0 0) en los menus
# Borramos los numeros fijos viejos de tu backup y ponemos 0 0 0
sed -i 's/--menu "SELECCIONA MODULO".*/--menu "SELECCIONA MODULO" 0 0 0 \\/' /storage/main_menu.sh
sed -i 's/--menu "Opciones del sistema:".*/--menu "Opciones del sistema:" 0 0 0 \\/' /storage/scripts/settings_tmux.sh 2>/dev/null
sed -i 's/--menu "Selecciona vector de ataque:".*/--menu "Selecciona vector de ataque:" 0 0 0 \\/' /storage/scripts/kali_net_menu.sh 2>/dev/null

echo ">>> PANTALLA COMPLETA RESTAURADA."
