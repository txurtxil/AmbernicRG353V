#!/bin/bash

echo "[*] 1. REVIRTIENDO LOCALES EN EL MENÚ PRINCIPAL..."
sed -i 's/export LC_ALL=C.UTF-8/export LC_ALL=C/g' /storage/main_menu.sh
sed -i 's/export LANG=C.UTF-8/export LANG=C/g' /storage/main_menu.sh

# Dejamos gtop limpio solo con su comodín (sin forzar variables globales)
sed -i 's/LC_ALL=C.UTF-8 gtop --utf-force/gtop --utf-force/g' /storage/main_menu.sh

echo "[*] 2. REVIRTIENDO LOCALES EN LOS SCRIPTS TÁCTICOS..."
if [ -f "/storage/scripts/start_kali_multitask.sh" ]; then
    sed -i 's/export LC_ALL=C.UTF-8/export LC_ALL=C/g' /storage/scripts/start_kali_multitask.sh
fi

if [ -f "/storage/scripts/start_war_room.sh" ]; then
    sed -i 's/export LC_ALL=C.UTF-8/export LC_ALL=C/g' /storage/scripts/start_war_room.sh
fi

echo "[*] 3. REANIMANDO EL MOTOR DOCKER CON EL ENTORNO LIMPIO..."
export LC_ALL=C
export LANG=C
/storage/scripts/start_docker_daemon.sh
sleep 3

echo ">>> SISTEMA SANEADO. Marcha atrás completada."
