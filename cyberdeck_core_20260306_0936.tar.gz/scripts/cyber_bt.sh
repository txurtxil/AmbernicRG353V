#!/bin/bash
export TERM=linux
export TERMINFO=/storage/terminfo
export DIALOGRC=/storage/.dialogrc

while true; do
    BT_STATE=$(hciconfig hci0 2>/dev/null | grep -o "UP RUNNING\|DOWN")
    [ -z "$BT_STATE" ] && BT_STATE="NO DETECTADO"

    dialog --clear --ascii-lines --shadow \
    --title " PANEL BLUETOOTH " \
    --menu "Estado Hardware: $BT_STATE\n\nSelecciona una accion:" 16 55 7 \
    "SCAN"    "BUSCAR Dispositivos (Analisis Profundo)" \
    "PRINTER" "Montar Impresora Termica (Inyeccion SPP)" \
    "ON"      "Encender Controlador" \
    "OFF"     "Apagar Controlador" \
    "PAIRED"  "Ver Historial de Dispositivos" \
    "REMOVE"  "Forzar Borrado de Dispositivo" \
    "SALIR"   "Volver" 2> /tmp/bt_panel.txt

    [ $? -ne 0 ] && break
    ACT=$(cat /tmp/bt_panel.txt)

    case "$ACT" in
        "SCAN")
            cat << 'INNER' > /tmp/bt_scan_task.sh
#!/bin/bash
echo "[*] Reiniciando demonio Bluetooth..."
systemctl restart bluetooth 2>/dev/null
sleep 1

echo "[*] Preparando hci0..."
rfkill unblock bluetooth 2>/dev/null
hciconfig hci0 down 2>/dev/null
sleep 1
hciconfig hci0 up 2>/dev/null
sleep 1

echo "[*] Limpiando procesos previos..."
pkill -9 -f bluetoothctl 2>/dev/null

echo "[*] Fase 1: Escaneo de espectro general (14s)..."
(
    echo "power on"
    echo "agent on"
    echo "default-agent"
    echo "discoverable on"
    echo "pairable on"
    echo "scan on"
    sleep 14
    echo "scan off"
    echo "quit"
) | bluetoothctl > /dev/null 2>&1 &
SCAN_PID=$!

for i in {1..14}; do
    echo "    -> Escuchando frecuencias... $i/14"
    sleep 1
done

wait $SCAN_PID 2>/dev/null

echo "[*] Fase 2: Interrogatorio Profundo (Forzando resolucion)..."
bluetoothctl devices > /tmp/bt_temp_raw.txt 2>&1
sed -i 's/\x1b\[[0-9;]*m//g' /tmp/bt_temp_raw.txt

while read -r line; do
    if echo "$line" | grep -q "^Device"; then
        MAC=$(echo "$line" | awk '{print $2}')
        NAME=$(echo "$line" | cut -d' ' -f3-)
        MAC_HYPHEN=$(echo "$MAC" | tr ':' '-')
        
        if [ "$NAME" == "$MAC_HYPHEN" ] || [ -z "$NAME" ]; then
            echo "    -> Interrogando MAC oculta: $MAC"
            echo "info $MAC" | timeout 1.5s bluetoothctl >/dev/null 2>&1
        fi
    fi
done < /tmp/bt_temp_raw.txt

echo "[*] Generando informe final..."
bluetoothctl devices > /tmp/bt_list_raw.txt 2>&1
sed -i 's/\x1b\[[0-9;]*m//g' /tmp/bt_list_raw.txt
sleep 1
INNER
            chmod +x /tmp/bt_scan_task.sh
            dialog --title " DIAGNOSTICO DE ESCANEO " --prgbox "/tmp/bt_scan_task.sh" 22 70
            
            > /tmp/bt_named.txt
            > /tmp/bt_unnamed.txt
            
            if [ -f /tmp/bt_list_raw.txt ]; then
                while read -r line; do
                    if echo "$line" | grep -q "^Device"; then
                        MAC=$(echo "$line" | awk '{print $2}')
                        NAME=$(echo "$line" | cut -d' ' -f3-)
                        
                        MAC_HYPHEN=$(echo "$MAC" | tr ':' '-')
                        if [ "$NAME" == "$MAC_HYPHEN" ] || [ -z "$NAME" ]; then
                            NAME="[Desconocido / Privado]"
                            echo "\"$MAC\" \"$NAME\"" >> /tmp/bt_unnamed.txt
                        else
                            echo "\"$MAC\" \"$NAME\"" >> /tmp/bt_named.txt
                        fi
                    fi
                done < /tmp/bt_list_raw.txt
            fi

            cat /tmp/bt_named.txt /tmp/bt_unnamed.txt > /tmp/bt_list.txt

            if [ -s /tmp/bt_list.txt ]; then
                dialog --title " RESULTADOS ORDENADOS " --menu "Selecciona para vincular:" 18 65 10 --file /tmp/bt_list.txt 2> /tmp/target_mac.txt
                if [ $? -eq 0 ]; then
                    MAC=$(cat /tmp/target_mac.txt)
                    
                    dialog --title " CODIGO PIN " --inputbox "Introduce el PIN del dispositivo\n(Para la impresora DPP-250 suele ser 0000):" 9 60 "0000" 2> /tmp/bt_pin.txt
                    PIN=$(cat /tmp/bt_pin.txt)
                    
                    cat << 'PAIR_TASK' > /tmp/bt_pair_task.sh
#!/bin/bash
MAC=$1
PIN=$2
echo "[*] Ejecutando comandos de vinculacion para $MAC..."
(
    echo "agent on"
    echo "default-agent"
    echo "pair $MAC"
    sleep 4
    echo "$PIN"
    sleep 2
    echo "trust $MAC"
    sleep 1
    echo "connect $MAC"
    sleep 4
    echo "quit"
) | bluetoothctl
echo ""
echo "[*] Proceso finalizado. Presiona OK para volver."
PAIR_TASK
                    chmod +x /tmp/bt_pair_task.sh
                    dialog --title " VINCULANDO A $MAC " --prgbox "/tmp/bt_pair_task.sh $MAC $PIN" 20 65
                fi
            else
                dialog --msgbox "La lista esta vacia.\nAsegurate de que tus dispositivos esten visibles y prueba otra vez." 6 60
            fi
            ;;
            
        "PRINTER")
            dialog --infobox "Despertando modulos del Kernel (rfcomm) y forzando Modo Compatibilidad SPP..." 4 60
            
            # 1. Despertamos el modulo del kernel
            modprobe rfcomm 2>/dev/null
            
            # 2. Forzamos a bluetoothd a usar el modo -C (Compatibilidad SPP)
            pkill -9 bluetoothd 2>/dev/null
            sleep 1
            /usr/lib/bluetooth/bluetoothd -C &
            sleep 3
            
            bluetoothctl devices > /tmp/bt_paired_raw.txt 2>&1
            sed -i 's/\x1b\[[0-9;]*m//g' /tmp/bt_paired_raw.txt
            > /tmp/bt_paired.txt
            while read -r line; do
                if echo "$line" | grep -q "^Device"; then
                    MAC=$(echo "$line" | awk '{print $2}')
                    NAME=$(echo "$line" | cut -d' ' -f3-)
                    [ -z "$NAME" ] && NAME="[Desconocido]"
                    echo "\"$MAC\" \"$NAME\"" >> /tmp/bt_paired.txt
                fi
            done < /tmp/bt_paired_raw.txt
            
            if [ -s /tmp/bt_paired.txt ]; then
                dialog --title " MONTAJE SPP (IMPRESORA) " --menu "Selecciona tu Datecs DPP-250:" 15 65 8 --file /tmp/bt_paired.txt 2> /tmp/printer_mac.txt
                if [ $? -eq 0 ]; then
                    PMAC=$(cat /tmp/printer_mac.txt)
                    dialog --infobox "Forzando canal Serie y montando /dev/rfcomm0...\n(El LED de la impresora parpadeara)" 4 60
                    
                    rfcomm release 0 2>/dev/null
                    sleep 1
                    
                    # Guardamos el error real en un log para estudiarlo si falla
                    rfcomm bind 0 $PMAC > /tmp/rfcomm_log.txt 2>&1
                    sleep 2
                    
                    if [ -e /dev/rfcomm0 ]; then
                        chmod 777 /dev/rfcomm0 2>/dev/null
                        dialog --msgbox "¡CONEXION ESTABLECIDA!\n\nEl puerto de la impresora es:\n/dev/rfcomm0\n\nVamos a imprimir un ticket de prueba..." 9 55
                        
                        echo -e "\n======================\n  CYBERDECK WAR-ROOM  \n======================\nImpresora: Datecs DPP-250\nEnlace SPP: ACTIVO\nStatus: ONLINE\n======================\n\n\n" > /dev/rfcomm0 2>/dev/null
                    else
                        ERR=$(cat /tmp/rfcomm_log.txt)
                        dialog --msgbox "Fallo a nivel de Kernel.\nLog: $ERR\n\nSi dice 'Protocol not supported' significa que los creadores de este firmware borraron el modulo de impresion (rfcomm.ko) para ahorrar espacio." 10 65
                    fi
                fi
            else
                dialog --msgbox "No hay dispositivos en memoria.\n\nUsa SCAN primero para emparejar la impresora." 7 60
            fi
            ;;
            
        "ON")  
            rfkill unblock bluetooth
            hciconfig hci0 up >/dev/null 2>&1 
            ;;
        "OFF") 
            hciconfig hci0 down >/dev/null 2>&1 
            ;;
        "PAIRED")
            bluetoothctl devices > /tmp/paired_raw.txt 2>&1
            sed -i 's/\x1b\[[0-9;]*m//g' /tmp/paired_raw.txt
            if [ -s /tmp/paired_raw.txt ]; then
                dialog --title " HISTORIAL DE DISPOSITIVOS " --textbox /tmp/paired_raw.txt 15 60
            else
                dialog --msgbox "No hay dispositivos en el historial." 6 60
            fi
            ;;
        "REMOVE")
            bluetoothctl devices > /tmp/bt_paired_raw.txt 2>&1
            sed -i 's/\x1b\[[0-9;]*m//g' /tmp/bt_paired_raw.txt
            > /tmp/bt_paired.txt
            while read -r line; do
                if echo "$line" | grep -q "^Device"; then
                    MAC=$(echo "$line" | awk '{print $2}')
                    NAME=$(echo "$line" | cut -d' ' -f3-)
                    
                    MAC_HYPHEN=$(echo "$MAC" | tr ':' '-')
                    if [ "$NAME" == "$MAC_HYPHEN" ] || [ -z "$NAME" ]; then
                        NAME="[Desconocido / Privado]"
                    fi

                    echo "\"$MAC\" \"$NAME\"" >> /tmp/bt_paired.txt
                fi
            done < /tmp/bt_paired_raw.txt
            
            if [ -s /tmp/bt_paired.txt ]; then
                dialog --title " FORZAR BORRADO " --menu "Selecciona la impresora atascada para eliminarla:" 15 65 8 --file /tmp/bt_paired.txt 2> /tmp/remove_mac.txt
                if [ $? -eq 0 ]; then
                    RM_MAC=$(cat /tmp/remove_mac.txt)
                    echo -e "remove $RM_MAC\nquit" | timeout 5s bluetoothctl >/dev/null 2>&1
                    dialog --msgbox "Memoria purgada. Dispositivo $RM_MAC eliminado." 5 50
                fi
            else
                dialog --msgbox "No hay dispositivos en la memoria para borrar." 5 45
            fi
            ;;
        "SALIR") break ;;
    esac
done
