#!/bin/sh
export DIALOGRC=/storage/.dialogrc_dev
while true; do
    dialog --timeout 120 --ascii-lines --shadow --clear \
    --backtitle "CyberDeck OS - LABORATORIO" \
    --title " ENTORNO DE DESARROLLO " \
    --menu "Selecciona herramienta:" 16 60 5 \
    "WINE"     "Pruebas y Ejecución de Wine" \
    "SQUASHFS" "Modificar partición 1 (SYSTEM)" \
    "SHELL"    "Shell limpia para compilar/instalar" \
    "BACK"     "Volver al menú principal" 2> /tmp/dev_choice.txt
    
    [ $? -ne 0 ] && continue
    CHOICE=$(cat /tmp/dev_choice.txt | tr -d '[:space:]')
    clear
    case "$CHOICE" in
        "WINE") /storage/scripts/bin/tmux new-session -A -s wine_test "/bin/sh" ;;
        "SQUASHFS") /storage/scripts/bin/tmux new-session -A -s squash "/bin/sh" ;;
        "SHELL") /storage/scripts/bin/tmux new-session -A -s dev_shell "/bin/sh" ;;
        "BACK") break ;;
    esac
done
