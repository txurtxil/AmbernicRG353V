#!/bin/sh

echo "[*] 1. REORGANIZANDO TRIPLE PANTALLA SHELL (MC a la derecha)..."
cat << 'WARROOM' > /storage/scripts/start_war_room.sh
#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export LANG=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

/storage/scripts/bin/tmux kill-session -t war_room 2>/dev/null
sleep 0.5

if ! docker ps >/dev/null 2>&1; then
    /storage/scripts/start_docker_daemon.sh
    sleep 3
fi

# PESTAÑA 1: ADMIN
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s war_room -n "Admin" "/bin/sh"

# Derecha: MC (Ahora en grande en toda la mitad derecha)
/storage/scripts/bin/tmux split-window -h -t war_room:Admin "TERM=linux /storage/scripts/docker/bin/docker run -it --rm -v /:/host_root -v /storage:/storage -w /storage --privileged kali-cyberdeck:latest mc || /bin/sh"

# Izquierda Abajo: Htop (En pequeño)
/storage/scripts/bin/tmux select-pane -t war_room:Admin.0
/storage/scripts/bin/tmux split-window -v -t war_room:Admin "TERM=linux htop || /bin/sh"

/storage/scripts/bin/tmux select-pane -t war_room:Admin.0

# PESTAÑAS 2 y 3 (SSH y Shell)
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room -n "SSH" "/storage/scripts/ssh_launcher.sh"
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room -n "Shell" "/bin/sh"

/storage/scripts/bin/tmux select-window -t war_room:Admin
/storage/scripts/bin/tmux attach-session -t war_room
clear
WARROOM
chmod +x /storage/scripts/start_war_room.sh


echo "[*] 2. CREANDO MENU TACTICO DE RED PARA KALI (Fing Clone + Nmap)..."
cat << 'KALIMENU' > /storage/scripts/kali_net_menu.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_kali
LOG_DIR="/storage/scripts/logs"
mkdir -p "$LOG_DIR"

while true; do
    dialog --clear --title " KALI NETWORK OPS " \
    --menu "Selecciona vector de ataque:" 14 60 4 \
    "1" "Mapeo de Red Local (Clon Fing)" \
    "2" "Analisis Profundo de Host (IP)" \
    "3" "Salir a Consola Libre" 2> /tmp/kali_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/kali_opt.txt)

    case "$OPT" in
        "1")
            # Ingenieria: Detectamos la IP de la consola para deducir la subred
            SUBNET=$(ip -o -f inet addr show | awk '/scope global/ {print $4}' | head -n 1)
            [ -z "$SUBNET" ] && SUBNET="192.168.1.0/24"
            FILE="$LOG_DIR/fing_scan_$(date +%Y%m%d_%H%M%S).log"
            clear
            echo "[+] Iniciando mapeo global rapido (ARP Ping) en: $SUBNET"
            echo "[+] Log: $FILE"
            # Nmap -sn -PR hace un barrido ARP (super rapido, ideal para clon Fing)
            /storage/scripts/docker/bin/docker exec -it kali_core nmap -sn -PR "$SUBNET" | tee "$FILE"
            echo ""
            echo "[+] Mapeo finalizado. Pulsa ENTER para volver."
            read pause
            ;;
        "2")
            dialog --clear --title " ANALISIS DE HOST " \
            --inputbox "IP Objetivo:" 0 0 "192.168.1." 2> /tmp/kali_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/kali_ip.txt | tr -d '[:space:]')
                FILE="$LOG_DIR/host_scan_${IP}_$(date +%Y%m%d_%H%M%S).log"
                clear
                echo "[+] Iniciando Escaneo Ofensivo Agresivo a $IP..."
                echo "[+] Se revisaran todos los puertos y SO. Log: $FILE"
                # Nmap agresivo optimizado en velocidad (-T4) y puertos maximos (-p-)
                /storage/scripts/docker/bin/docker exec -it kali_core nmap -A -T4 -p- -Pn "$IP" | tee "$FILE"
                echo ""
                echo "[+] Escaneo finalizado. Pulsa ENTER para volver."
                read pause
            fi
            ;;
        "3")
            break
            ;;
    esac
done
clear
/bin/sh
KALIMENU
chmod +x /storage/scripts/kali_net_menu.sh


echo "[*] 3. REORGANIZANDO TRIPLE PANTALLA KALI..."
cat << 'KALI' > /storage/scripts/start_kali_multitask.sh
#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export LANG=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

if ! docker ps >/dev/null 2>&1; then
    /storage/scripts/start_docker_daemon.sh
    sleep 3
fi

if ! docker ps | grep -q kali_core; then
    docker run -d --rm --name kali_core --net=host --privileged kali-cyberdeck:latest sleep infinity
    sleep 3 
fi

/storage/scripts/bin/tmux kill-session -t kali_tactico 2>/dev/null
sleep 0.5

# Izquierda: Todo el alto para el Menu de Red (Comodidad visual)
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s kali_tactico "/storage/scripts/kali_net_menu.sh"

# Derecha Arriba: Monitor de puertos en tiempo real
/storage/scripts/bin/tmux split-window -h -t kali_tactico "docker exec -it kali_core watch -n 2 'netstat -tulnp | grep LISTEN'"

# Derecha Abajo: Consola libre de Kali
/storage/scripts/bin/tmux select-pane -t kali_tactico:0.1
/storage/scripts/bin/tmux split-window -v -t kali_tactico "docker exec -it kali_core /bin/bash"

# Enfocar el Menu
/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux attach-session -t kali_tactico
clear
KALI
chmod +x /storage/scripts/start_kali_multitask.sh


echo "[*] 4. HACKEANDO EL TECLADO (Boton Y = Borrar)..."
# Inyectamos el atajo para borrar en tu mando
sed -i '/backspace/d' /storage/scripts/keyb/universal.gptk 2>/dev/null
echo "y = backspace" >> /storage/scripts/keyb/universal.gptk

echo ">>> ACTUALIZACION MASIVA COMPLETADA."
