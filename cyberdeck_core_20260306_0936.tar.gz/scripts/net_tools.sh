#!/bin/bash
# --- VARIABLES DE ENTORNO ---
export TERM=linux
export TERMINFO=/storage/terminfo
export DIALOGRC=/storage/.dialogrc

while true; do
    # Menú Principal de Herramientas de Red
    dialog --clear --ascii-lines --shadow \
    --backtitle "CyberDeck OS - Diagnóstico de Red" \
    --title " HERRAMIENTAS DE RED TÁCTICAS " \
    --menu "Selecciona una operación de diagnóstico:" 15 60 5 \
    "IP"      "Ver mi IP y Rutas actuales" \
    "PING"    "Test de Conexión (Ping a Google)" \
    "ROUTER"  "Ping al Router (Puerta de Enlace)" \
    "SCAN"    "Escáner Rápido de Puertos (20-1000)" \
    "SALIR"   "Volver a la terminal pura" 2> /tmp/net_choice.txt

    [ $? -ne 0 ] && break
    CHOICE=$(cat /tmp/net_choice.txt | tr -d '[:space:]')
    [ -z "$CHOICE" ] && continue

    clear
    case "$CHOICE" in
        "IP")
            # Recolectamos info de red
            MY_IP=$(ip a | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}')
            MY_ROUTE=$(ip route | head -n 3)
            dialog --title " [ ESTADO DE RED ] " \
            --msgbox "Interfaces Activas:\n$MY_IP\n\nTablas de Ruta:\n$MY_ROUTE" 12 55
            ;;
        "PING")
            # Ejecutamos ping y guardamos salida
            dialog --infobox "Lanzando ráfaga de paquetes a 8.8.8.8...\nEspera un momento." 5 50
            ping -c 4 8.8.8.8 > /tmp/ping_res.txt 2>&1
            dialog --title " [ RESULTADO PING GOOGLE ] " \
            --textbox /tmp/ping_res.txt 12 60
            ;;
        "ROUTER")
            # Detectamos Gateway y hacemos ping
            GW=$(ip route | awk '/default/ {print $3}')
            if [ -z "$GW" ]; then
                dialog --msgbox "Error: No se detectó una Puerta de Enlace activa." 6 45
            else
                dialog --infobox "Haciendo ping al Router en $GW..." 5 50
                ping -c 4 "$GW" > /tmp/ping_gw.txt 2>&1
                dialog --title " [ PING AL ROUTER ] " \
                --textbox /tmp/ping_gw.txt 12 60
            fi
            ;;
        "SCAN")
            # Pedimos IP y escaneamos
            dialog --title " ESCÁNER DE PUERTOS " \
            --inputbox "Introduce la IP del objetivo:\n(Ejemplo: 192.168.1.1)" 10 45 "192.168.1.1" 2> /tmp/scan_ip.txt
            
            if [ $? -eq 0 ]; then
                TARGET=$(cat /tmp/scan_ip.txt)
                dialog --infobox "Escaneando puertos tácticos en $TARGET...\n(Este proceso puede tardar unos segundos)" 5 55
                # Usamos nc para escanear y filtramos solo los abiertos
                nc -z -v -w 1 "$TARGET" 20-1000 2>&1 | grep "succeeded" > /tmp/scan_res.txt
                
                if [ -s /tmp/scan_res.txt ]; then
                    dialog --title " [ PUERTOS ABIERTOS EN $TARGET ] " \
                    --textbox /tmp/scan_res.txt 15 65
                else
                    dialog --msgbox "No se encontraron puertos abiertos en el rango 20-1000." 6 55
                fi
            fi
            ;;
        "SALIR")
            break
            ;;
    esac
done
clear
echo "[*] Herramientas de red cerradas. Estás en la shell de la pestaña."
sh
