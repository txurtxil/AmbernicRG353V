#!/bin/bash
# =================================================================
#  CYBERDECK: REINSTALACIÓN PURA DE DOCKER (MOTOR Y BINARIOS)
# =================================================================

DOCKER_DIR="/storage/scripts/docker"
DOCKER_VERSION="24.0.9" # Versión estática estable para arquitecturas empotradas

echo "[*] 1. PREPARANDO NUEVA ESTRUCTURA (DATA, BIN, RUN)..."
mkdir -p $DOCKER_DIR/bin
mkdir -p $DOCKER_DIR/run/exec
mkdir -p $DOCKER_DIR/data

echo "[*] 2. DESCARGANDO BINARIOS ESTÁTICOS DE DOCKER (aarch64)..."
# Descargamos directamente de los repositorios oficiales de Docker
wget -O /tmp/docker.tgz "https://download.docker.com/linux/static/stable/aarch64/docker-${DOCKER_VERSION}.tgz"

if [ ! -f /tmp/docker.tgz ]; then
    echo "[-] ERROR: No se pudo descargar Docker. ¿Estás conectado al Wi-Fi?"
    exit 1
fi

echo "[*] 3. EXTRAYENDO E INSTALANDO BINARIOS..."
tar -xzf /tmp/docker.tgz -C /tmp/
mv /tmp/docker/* $DOCKER_DIR/bin/
chmod +x $DOCKER_DIR/bin/*
rm -rf /tmp/docker*

# Creamos enlaces simbólicos para que los comandos de consola funcionen siempre
ln -sf $DOCKER_DIR/bin/docker /usr/local/bin/docker
ln -sf $DOCKER_DIR/bin/dockerd /usr/local/bin/dockerd

echo "[*] 4. CREANDO EL DEMONIO DE ARRANQUE (El motor principal)..."
cat << 'DAEMON' > /storage/scripts/start_docker_daemon.sh
#!/bin/bash
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

# Matar demonios zombis previos
pkill -9 -f dockerd 2>/dev/null
pkill -9 -f containerd 2>/dev/null
sleep 1

echo "[+] Levantando motor Docker en la nueva partición..."
# Lanzamos dockerd forzando todas las rutas de estado a /storage
nohup /storage/scripts/docker/bin/dockerd \
    --data-root /storage/scripts/docker/data \
    --host unix:///storage/scripts/docker/run/docker.sock \
    --pidfile /storage/scripts/docker/run/docker.pid \
    --exec-root /storage/scripts/docker/run/exec \
    > /storage/scripts/docker/dockerd.log 2>&1 &
DAEMON
chmod +x /storage/scripts/start_docker_daemon.sh

echo "[*] 5. INYECTANDO RUTAS EN EL ENTORNO GLOBAL..."
# Para que cuando escribas 'docker ps' en cualquier terminal manual, funcione
if ! grep -q "DOCKER_HOST" ~/.bashrc 2>/dev/null; then
    echo 'export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"' >> ~/.bashrc
    echo 'export PATH=$PATH:/storage/scripts/docker/bin' >> ~/.bashrc
fi

echo "[*] ARRANCANDO EL MOTOR POR PRIMERA VEZ..."
/storage/scripts/start_docker_daemon.sh
sleep 4

# Test de vida del motor
if /storage/scripts/docker/bin/docker -H unix:///storage/scripts/docker/run/docker.sock info > /dev/null 2>&1; then
    echo ">>> ¡ÉXITO! Docker ha resucitado en su nueva casa (/storage/scripts/docker)."
    echo ">>> La reconstrucción de tu entorno está lista."
else
    echo ">>> [!] Algo falló al arrancar el motor. Revisa el log en /storage/scripts/docker/dockerd.log"
fi
