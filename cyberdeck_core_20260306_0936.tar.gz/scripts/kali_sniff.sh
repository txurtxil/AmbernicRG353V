#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export DIALOGRC=/storage/.dialogrc
DOCKER="/storage/docker/bin/docker"

mkdir -p /storage/kali/logs

while true; do
    dialog --clear --shadow --title " INTERCEPTOR DE TRAFICO " \
    --menu "Filtro de captura en interfaz wlan0:" 15 62 6 \
    "1" "Monitor Global (Ver TODO el trafico)" \
    "2" "Espiar IP Especifica (Entrada y Salida)" \
    "3" "Cazar Trafico Web (HTTP en texto plano)" \
    "4" "Cazar Credenciales en Claro (FTP/Telnet)" \
    "5" "Analisis Profundo Tshark (Wireshark de consola)" \
    "6" "--> Abrir Consola Libre de Kali" \
    "0" "<-- Salir de esta ventana" 2> /tmp/s_opt.txt
    
    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/s_opt.txt)
    
    case "$OPT" in
        1) clear; LOG="/storage/kali/logs/tcpdump_global_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host --privileged kali-cyberdeck:latest tcpdump -i wlan0 -n 2>&1 | tee "$LOG" ;;
        2) dialog --inputbox "IP a espiar:" 8 40 "192.168.1." 2> /tmp/ip.txt
           [ $? -eq 0 ] && { clear; LOG="/storage/kali/logs/tcpdump_ip_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host --privileged kali-cyberdeck:latest tcpdump -i wlan0 -n host $(cat /tmp/ip.txt) 2>&1 | tee "$LOG"; } ;;
        3) clear; LOG="/storage/kali/logs/tcpdump_http_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host --privileged kali-cyberdeck:latest tcpdump -i wlan0 -n tcp port 80 -A 2>&1 | tee "$LOG" ;;
        4) clear; LOG="/storage/kali/logs/tcpdump_creds_$(date +%Y%m%d_%H%M%S).log"; echo -e "\033[1;31m[*] Escuchando puertos 21 y 23...\033[0m"; $DOCKER run -it --rm --net=host --privileged kali-cyberdeck:latest tcpdump -i wlan0 -n port 21 or port 23 -A 2>&1 | tee "$LOG" ;;
        5) clear; LOG="/storage/kali/logs/tshark_$(date +%Y%m%d_%H%M%S).log"; $DOCKER run -it --rm --net=host --privileged kali-cyberdeck:latest /bin/bash -c "tshark -i wlan0 || echo 'Instala: apt install tshark -y'" 2>&1 | tee "$LOG" ;;
        6) clear; $DOCKER run -it --rm --net=host --privileged kali-cyberdeck:latest /bin/bash ;;
        0) break ;;
    esac
    echo -e "\n\033[1;33m[ Pulsa ENTER para volver al menu del Sniffer ]\033[0m"
    read dummy
done
