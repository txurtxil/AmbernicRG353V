#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main
sleep 0.2

# Instalacion silenciosa en background
docker exec kali_core bash -c "which iperf3 >/dev/null || (apt-get update && apt-get install -y iperf3)" >/dev/null 2>&1 &

# Calculamos tu IP actual para mostrarla en las instrucciones
IP_LOCAL=$(ip -o -f inet addr show | awk '/scope global/ {print $4}' | cut -d/ -f1 | head -n 1)
[ -z "$IP_LOCAL" ] && IP_LOCAL="192.168.1.X"

while true; do
    dialog --clear --title " SYSADMIN TOOLS " \
    --menu "Herramientas de conexion:" 0 0 0 \
    "1" "Conexion SSH (Pre-config)" \
    "2" "Iperf3 (Modo Servidor)" \
    "3" "Iperf3 (Modo Cliente)" \
    "4" "Salir a Consola Libre" 2> /tmp/k_tools.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/k_tools.txt)

    case "$OPT" in
        "1")
            dialog --clear --title " SSH SECURE SHELL " \
            --inputbox "IP Destino:" 0 0 "192.168.1." 2> /tmp/k_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/k_ip.txt | tr -d '[:space:]')
                clear
                echo "[+] Conectando a $IP..."
                docker exec -it kali_core ssh "root@$IP"
                echo "Conexion cerrada. ENTER para volver."
                read pause
            fi
            ;;
        "2")
            clear
            echo "======================================================"
            echo "[+] INICIANDO SERVIDOR IPERF3 EN ESTA CONSOLA"
            echo "======================================================"
            echo "[i] INSTRUCCIONES PARA EL EQUIPO REMOTO (CLIENTE):"
            echo "    Abre la terminal en el otro PC/Movil y ejecuta:"
            echo ""
            echo "          iperf3 -c $IP_LOCAL"
            echo ""
            echo "======================================================"
            echo "[+] Esperando conexiones entrantes..."
            docker exec -it kali_core iperf3 -s
            echo "Servidor detenido. ENTER para volver."
            read pause
            ;;
        "3")
            dialog --clear --title " IPERF3 CLIENTE " \
            --inputbox "IP del Servidor (Remoto):" 0 0 "192.168.1." 2> /tmp/k_ip.txt
            if [ $? -eq 0 ]; then
                IP=$(cat /tmp/k_ip.txt | tr -d '[:space:]')
                clear
                echo "======================================================"
                echo "[+] MODO CLIENTE: TESTEANDO ANCHO DE BANDA HACIA $IP"
                echo "======================================================"
                echo "[i] ASEGURATE DE QUE EL EQUIPO REMOTO ESTA LISTO:"
                echo "    El otro equipo debe haber ejecutado primero:"
                echo "          iperf3 -s"
                echo "======================================================"
                docker exec -it kali_core iperf3 -c "$IP"
                echo ""
                echo "Test finalizado. ENTER para volver."
                read pause
            fi
            ;;
        "4") break ;;
    esac
done
clear
/bin/sh
