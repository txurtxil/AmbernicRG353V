#!/bin/bash

echo "[*] APLICANDO INYECCIÓN DE PARÁMETROS PARA KERNEL EMPOTRADO..."

cat << 'DAEMON' > /storage/scripts/start_docker_daemon.sh
#!/bin/bash
# 1. Le decimos que los binarios están aquí (Soluciona el Read-Only)
export PATH=/storage/scripts/docker/bin:$PATH
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

# Matar procesos colgados
pkill -9 -f dockerd 2>/dev/null
pkill -9 -f containerd 2>/dev/null
sleep 1

echo "[+] Levantando motor Docker optimizado..."
# 2. Añadimos --iptables=false y --bridge=none (Soluciona el fallo de MASQUERADE)
nohup /storage/scripts/docker/bin/dockerd \
    --data-root /storage/scripts/docker/data \
    --host unix:///storage/scripts/docker/run/docker.sock \
    --pidfile /storage/scripts/docker/run/docker.pid \
    --exec-root /storage/scripts/docker/run/exec \
    --iptables=false \
    --bridge=none \
    > /storage/scripts/docker/dockerd.log 2>&1 &
DAEMON

chmod +x /storage/scripts/start_docker_daemon.sh

echo "[*] REINICIANDO EL MOTOR CON LAS NUEVAS REGLAS..."
/storage/scripts/start_docker_daemon.sh
sleep 4

if /storage/scripts/docker/bin/docker -H unix:///storage/scripts/docker/run/docker.sock info > /dev/null 2>&1; then
    echo ">>> ¡BINGO TOTAL! El motor Docker ha arrancado perfectamente."
    echo ">>> Ya puedes ir a crear tu contenedor Kali."
else
    echo ">>> [-] Algo falló. Revisando el final del log:"
    tail -n 5 /storage/scripts/docker/dockerd.log
fi
