#!/bin/sh
export DIALOGRC=/storage/.dialogrc_main
export TERM=linux

while true; do
    dialog --clear --title " GESTION DE ENERGIA " \
    --menu "Selecciona una accion:" 14 55 5 \
    "1" "Activar Salvapantallas (Modo Ahorro)" \
    "2" "Reiniciar CyberDeck" \
    "3" "Apagar CyberDeck" \
    "4" "Salir a Terminal Plana (Modo Debug)" \
    "5" "Volver al Menu Principal" 2> /tmp/power_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/power_opt.txt | tr -d '[:space:]')

    case "$OPT" in
        "1")
            clear
            # Ocultamos el cursor del sistema
            echo -e "\033[?25l"
            echo -e "\n\n\n\n\n\n\n\n\t    [ MODO SUSPENSION ]"
            echo -e "\tPulsa el boton 'A' para despertar..."
            # Esperamos a que el usuario pulse Enter (A)
            read pause
            # Volvemos a mostrar el cursor
            echo -e "\033[?25h"
            ;;
        "2")
            dialog --title " CONFIRMAR " --yesno "¿Seguro que quieres REINICIAR el sistema?" 6 45
            if [ $? -eq 0 ]; then
                clear
                echo "[!] Reiniciando motores..."
                sleep 1
                reboot
                exit 0
            fi
            ;;
        "3")
            dialog --title " CONFIRMAR " --yesno "¿Seguro que quieres APAGAR el sistema?" 6 45
            if [ $? -eq 0 ]; then
                clear
                echo "[!] Apagando hardware..."
                sleep 1
                poweroff
                exit 0
            fi
            ;;
        "4")
            # Codigo 99 le dira al menu principal que se cierre por completo
            exit 99
            ;;
        "5")
            break
            ;;
    esac
done
clear
