#!/bin/sh

echo "[*] INYECTANDO SISTEMA DE BACKUP EN SETTINGS..."
cat << 'SETTINGS' > /storage/scripts/settings_tmux.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main

while true; do
    dialog --clear --title " AJUSTES Y SEGURIDAD " \
    --menu "Opciones del sistema:" 0 0 0 \
    "1" "Conexion Wi-Fi (Menu Nativo)" \
    "2" "Conexion Bluetooth (Menu Nativo)" \
    "3" "Backup del Sistema (Solo scripts y config)" \
    "4" "Volver al Menu Principal" 2> /tmp/set_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/set_opt.txt | tr -d '[:space:]')

    case "$OPT" in
        "1")
            if [ -f "/storage/scripts/cyber_wifi.sh" ]; then
                /storage/scripts/cyber_wifi.sh
            else
                dialog --msgbox "Falta cyber_wifi.sh en /storage/scripts/" 5 40
            fi
            ;;
        "2")
            if [ -f "/storage/scripts/cyber_bt.sh" ]; then
                /storage/scripts/cyber_bt.sh
            else
                dialog --msgbox "Falta cyber_bt.sh en /storage/scripts/" 5 40
            fi
            ;;
        "3")
            clear
            echo "[*] Analizando archivos esenciales..."
            DEST_DIR="/storage/scripts/backup"
            mkdir -p "$DEST_DIR"
            FILE="$DEST_DIR/cyberdeck_core_$(date +%Y%m%d_%H%M).tar.gz"
            
            echo "[*] Comprimiendo el cerebro del CyberDeck..."
            echo "[!] (Ignorando contenedores Docker para ahorrar espacio)"
            
            # Guardamos todo pero EXCLUIMOS las carpetas pesadas
            tar --exclude='/storage/scripts/docker/data' \
                --exclude='/storage/scripts/docker/build_kali' \
                --exclude='/storage/scripts/backup' \
                --exclude='/storage/scripts/logs' \
                -czf "$FILE" \
                /storage/main_menu.sh \
                /storage/.dialogrc* \
                /storage/.tmux.conf \
                /storage/terminfo \
                /storage/scripts/ 2>/dev/null
            
            if [ $? -eq 0 ]; then
                echo ""
                echo "[+] COPIA DE SEGURIDAD CREADA CON EXITO!"
                echo "[+] Ruta: $FILE"
                echo ""
                echo "Guarda este archivo (.tar.gz) a salvo fuera de la consola."
            else
                echo "[-] Error al crear la copia de seguridad."
            fi
            
            echo ""
            echo "Pulsa ENTER (A) para volver..."
            read pause
            ;;
        "4")
            break
            ;;
    esac
done
clear
SETTINGS
chmod +x /storage/scripts/settings_tmux.sh

echo ">>> MENU SETTINGS ACTUALIZADO. Tu salvavidas esta listo."
