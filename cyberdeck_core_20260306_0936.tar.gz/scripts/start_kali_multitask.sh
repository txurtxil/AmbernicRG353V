#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

# EL PUENTE HACIA EL MOTOR (Esto arregla el fallo del primer arranque)
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

# Despertador de Docker (Misma logica blindada de la Shell)
if ! docker ps >/dev/null 2>&1; then
    echo "[*] Despertando motor Docker..."
    /storage/scripts/start_docker_daemon.sh
    sleep 3
fi

# Levantamos el contenedor de Kali
if ! docker ps | grep -q kali_core; then
    echo "[*] Levantando nucleo tactico..."
    docker run -d --rm --name kali_core --net=host --pid=host --privileged kali-cyberdeck:latest sleep infinity
    sleep 3 
fi

/storage/scripts/bin/tmux kill-session -t kali_tactico 2>/dev/null
sleep 0.5

# Izquierda: Menu de Auditoria Centrado
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s kali_tactico "/storage/scripts/kali_net_menu.sh"

# Derecha Arriba: Monitor de red
/storage/scripts/bin/tmux split-window -h -t kali_tactico "docker exec -it kali_core watch -n 2 'netstat -tulnp | grep LISTEN'"

# Derecha Abajo: Menu SysAdmin (SSH + Iperf3)
/storage/scripts/bin/tmux select-pane -t kali_tactico:0.1
/storage/scripts/bin/tmux split-window -v -t kali_tactico "/storage/scripts/kali_tools_menu.sh"

/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux attach-session -t kali_tactico
clear
