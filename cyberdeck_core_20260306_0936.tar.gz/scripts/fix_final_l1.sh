#!/bin/sh

echo "[*] 1. RESTAURANDO MENU SETTINGS (Sin Copia de Seguridad)..."
cat << 'SETTINGS' > /storage/scripts/settings_tmux.sh
#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main

while true; do
    dialog --clear --title " AJUSTES Y SEGURIDAD " \
    --menu "Opciones del sistema:" 0 0 0 \
    "1" "Conexion Wi-Fi (Menu Nativo)" \
    "2" "Conexion Bluetooth (Menu Nativo)" \
    "3" "Volver al Menu Principal" 2> /tmp/set_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/set_opt.txt | tr -d '[:space:]')

    case "$OPT" in
        "1")
            if [ -f "/storage/scripts/cyber_wifi.sh" ]; then
                /storage/scripts/cyber_wifi.sh
            else
                dialog --msgbox "Falta cyber_wifi.sh en /storage/scripts/" 5 40
            fi
            ;;
        "2")
            if [ -f "/storage/scripts/cyber_bt.sh" ]; then
                /storage/scripts/cyber_bt.sh
            else
                dialog --msgbox "Falta cyber_bt.sh en /storage/scripts/" 5 40
            fi
            ;;
        "3") break ;;
    esac
done
clear
SETTINGS
chmod +x /storage/scripts/settings_tmux.sh

echo "[*] 2. RECONSTRUYENDO EL MAPEO DE L1 (TECLADO EN PANTALLA)..."
# Limpiamos cualquier rastro roto de L1
sed -i '/l1 =/d' /storage/scripts/keyb/universal.gptk 2>/dev/null
sed -i '/l1=/d' /storage/scripts/keyb/universal.gptk 2>/dev/null

# Inyectamos F11, que es el boton maestro para invocar el OSK (On Screen Keyboard)
echo "l1 = f11" >> /storage/scripts/keyb/universal.gptk

echo "[*] 3. REINICIANDO DRIVER DEL MANDO..."
killall -9 gptokeyb 2>/dev/null
/usr/bin/gptokeyb "foot" -c "/storage/scripts/keyb/universal.gptk" &

echo ">>> SISTEMA RESTAURADO. Opciones de backup eliminadas y L1 mapeado."
