#!/bin/sh
export TERM=linux
export DIALOGRC=/storage/.dialogrc_main

while true; do
    dialog --clear --title " AJUSTES Y SEGURIDAD " \
    --menu "Opciones del sistema:" 18 64 9 \
    "1" "Conexion Wi-Fi (Menu Nativo)" \
    "2" "Conexion Bluetooth (Menu Nativo)" \
    "3" "Backup del Sistema (Cerebro v2.6 Laser)" \
    "4" "Volver al Menu Principal" 2> /tmp/set_opt.txt

    [ $? -ne 0 ] && break
    OPT=$(cat /tmp/set_opt.txt | tr -d '[:space:]')

    case "$OPT" in
        "1")
            if [ -f "/storage/scripts/cyber_wifi.sh" ]; then
                /storage/scripts/cyber_wifi.sh
            else
                dialog --msgbox "Falta cyber_wifi.sh en /storage/scripts/" 5 40
            fi
            ;;
        "2")
            if [ -f "/storage/scripts/cyber_bt.sh" ]; then
                /storage/scripts/cyber_bt.sh
            else
                dialog --msgbox "Falta cyber_bt.sh en /storage/scripts/" 5 40
            fi
            ;;
        "3")
            clear
            echo "[*] Analizando archivos esenciales..."
            DEST_DIR="/storage/scripts/backup"
            mkdir -p "$DEST_DIR"
            
            FILE_NAME="cyberdeck_core_$(date +%Y%m%d_%H%M).tar.gz"
            FILE_PATH="$DEST_DIR/$FILE_NAME"
            
            echo "[*] Comprimiendo el cerebro del CyberDeck (v2.6)..."
            echo "[+] Extrayendo solo configuraciones clave (Cirugia Laser)..."
            
            cd /storage || exit
            
            # Solo apuntamos a los archivos exactos, nada de carpetas enteras
            tar --exclude='scripts/docker' \
                --exclude='scripts/backup' \
                --exclude='scripts/logs' \
                --exclude='*.tar.gz' \
                --exclude='*.xz' \
                --exclude='*.img' \
                -czf "$FILE_PATH" \
                main_menu.sh \
                .dialogrc* \
                .tmux.conf \
                terminfo \
                .config/foot/foot.ini \
                .config/wpa_supplicant.conf \
                *.gptk \
                scripts/ 2>/dev/null
            
            STATUS=$?
            
            if [ $STATUS -eq 0 ] || [ $STATUS -eq 1 ]; then
                SIZE=$(du -h "$FILE_PATH" | awk '{print $1}')
                echo ""
                echo "[+] COPIA DE SEGURIDAD CREADA CON EXITO!"
                echo "[+] Ruta: $FILE_PATH"
                echo "[+] Tamano real: $SIZE"
                echo ""
                echo "Guarda este archivo a salvo en tu PC o GitHub."
            else
                echo "[-] Error CRITICO al crear la copia (Codigo: $STATUS)."
            fi
            
            cd - > /dev/null
            
            echo ""
            echo "Pulsa ENTER (A) para volver..."
            read pause
            ;;
        "4")
            break
            ;;
    esac
done
clear
