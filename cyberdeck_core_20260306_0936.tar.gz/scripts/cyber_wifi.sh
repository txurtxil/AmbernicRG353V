#!/bin/bash
export TERM=linux
export TERMINFO=/storage/terminfo
export DIALOGRC=/storage/.dialogrc
export PATH=$PATH:/usr/bin:/usr/sbin:/bin:/sbin

# NUEVA RUTA: Apuntamos a la particion que SI permite escribir
mkdir -p /storage/.config
WPA_CONF="/storage/.config/wpa_supplicant.conf"

# Nos aseguramos de que el archivo base existe
if [ ! -f "$WPA_CONF" ]; then
    echo "ctrl_interface=/var/run/wpa_supplicant" > "$WPA_CONF"
    echo "update_config=1" >> "$WPA_CONF"
fi

while true; do
    IP=$(ip -4 addr show wlan0 2>/dev/null | grep "inet" | awk '{print $2}' | cut -d/ -f1 | head -n 1)
    [ -z "$IP" ] && IP="Sin IP asignada"

    SSID=$(iw dev wlan0 link 2>/dev/null | grep "\bSSID:" | sed 's/^\s*SSID: //')
    [ -z "$SSID" ] && SSID="DESCONECTADO"

    dialog --clear --ascii-lines --shadow \
    --title " PANEL DE COMUNICACIONES WI-FI (v2.1) " \
    --menu "Enlace: $SSID\nIPv4: $IP\n\nSelecciona un vector de accion:" 18 65 7 \
    "SCAN"    "Escanear y Seleccionar Red (Interactivo)" \
    "SAVED"   "Ver Redes Guardadas (Memoria)" \
    "HIDDEN"  "Conectar a Red Oculta (Manual)" \
    "ON"      "Activar Radio y Reiniciar Motor" \
    "OFF"     "Desactivar Radio (Modo Avion)" \
    "RESTART" "Forzar Renegociacion de IP (DHCP)" \
    "STATUS"  "Diagnostico de Interfaz e IP" \
    "SALIR"   "Volver al Menu Principal" 2> /tmp/wifi_action.txt

    [ $? -ne 0 ] && break
    ACT=$(cat /tmp/wifi_action.txt)

    case "$ACT" in
        "SCAN")
            dialog --infobox "Activando antena y barriendo el espectro...\n(Espera 4 segundos)" 4 50
            rfkill unblock wifi 2>/dev/null
            ip link set wlan0 up 2>/dev/null
            sleep 2
            
            > /tmp/wifi_list.txt
            iw dev wlan0 scan 2>/dev/null | grep "\bSSID:" | sed 's/^\s*SSID: //' | grep -v "^$" | sort -u > /tmp/wifi_raw.txt
            
            while read -r line; do
                echo "\"$line\" \"Autenticar\"" >> /tmp/wifi_list.txt
            done < /tmp/wifi_raw.txt

            if [ -s /tmp/wifi_list.txt ]; then
                dialog --title " RADAR WI-FI " --menu "Selecciona el objetivo:" 18 65 10 --file /tmp/wifi_list.txt 2> /tmp/w_target.txt
                if [ $? -eq 0 ]; then
                    TARGET_SSID=$(cat /tmp/w_target.txt)
                    
                    dialog --title " PROTOCOLO DE SEGURIDAD " --insecure --passwordbox "Introduce la contrasena para:\n[$TARGET_SSID]\n\n(Deja en blanco si es una red ABIERTA)" 10 55 2> /tmp/w_pass.txt
                    if [ $? -eq 0 ]; then
                        TARGET_PASS=$(cat /tmp/w_pass.txt)
                        dialog --infobox "Inyectando credenciales en /storage...\nPor favor, espera 10 segundos." 5 55
                        
                        sed -i "/ssid=\"$TARGET_SSID\"/,/}/d" "$WPA_CONF"
                        
                        echo "network={" >> "$WPA_CONF"
                        echo "    ssid=\"$TARGET_SSID\"" >> "$WPA_CONF"
                        if [ -z "$TARGET_PASS" ]; then
                            echo "    key_mgmt=NONE" >> "$WPA_CONF"
                        else
                            echo "    psk=\"$TARGET_PASS\"" >> "$WPA_CONF"
                        fi
                        echo "}" >> "$WPA_CONF"
                        
                        killall -9 wpa_supplicant 2>/dev/null
                        sleep 1
                        # Arrancamos apuntando a la nueva ruta
                        /usr/bin/wpa_supplicant -B -i wlan0 -c "$WPA_CONF" 2>/dev/null
                        
                        sleep 5
                        udhcpc -i wlan0 -q 2>/dev/null
                    fi
                fi
            else
                dialog --msgbox "El radar no encontro ninguna red Wi-Fi.\nAsegurate de que la antena esta en ON." 6 50
            fi
            ;;
            
        "SAVED")
            > /tmp/w_saved_menu.txt
            grep "ssid=" "$WPA_CONF" | cut -d'"' -f2 | grep -v "^$" > /tmp/w_saved_raw.txt
            
            while read -r line; do
                echo "\"$line\" \"Guardada en sistema\"" >> /tmp/w_saved_menu.txt
            done < /tmp/w_saved_raw.txt
            
            if [ -s /tmp/w_saved_menu.txt ]; then
                dialog --title " REDES EN MEMORIA " --menu "Selecciona una red para BORRARLA:" 18 60 10 --file /tmp/w_saved_menu.txt 2> /tmp/w_del_id.txt
                if [ $? -eq 0 ]; then
                    DEL_SSID=$(cat /tmp/w_del_id.txt)
                    sed -i "/ssid=\"$DEL_SSID\"/,/}/d" "$WPA_CONF"
                    killall -9 wpa_supplicant 2>/dev/null
                    /usr/bin/wpa_supplicant -B -i wlan0 -c "$WPA_CONF" 2>/dev/null
                    dialog --infobox "Red purgada de la memoria." 3 40
                    sleep 1
                fi
            else
                dialog --msgbox "No hay redes guardadas en el archivo de configuracion." 5 55
            fi
            ;;

        "HIDDEN")
            dialog --title " OBJETIVO OCULTO " --inputbox "Introduce el SSID exacto de la red:" 8 50 2> /tmp/w_ssid.txt
            if [ $? -eq 0 ]; then
                TARGET_SSID=$(cat /tmp/w_ssid.txt)
                [ -z "$TARGET_SSID" ] && continue
                
                dialog --title " SEGURIDAD " --insecure --passwordbox "Introduce la clave:" 8 50 2> /tmp/w_pass.txt
                if [ $? -eq 0 ]; then
                    TARGET_PASS=$(cat /tmp/w_pass.txt)
                    dialog --infobox "Aplicando configuracion..." 3 40
                    
                    sed -i "/ssid=\"$TARGET_SSID\"/,/}/d" "$WPA_CONF"
                    echo "network={" >> "$WPA_CONF"
                    echo "    ssid=\"$TARGET_SSID\"" >> "$WPA_CONF"
                    echo "    scan_ssid=1" >> "$WPA_CONF"
                    [ -n "$TARGET_PASS" ] && echo "    psk=\"$TARGET_PASS\"" >> "$WPA_CONF"
                    echo "}" >> "$WPA_CONF"
                    
                    killall -9 wpa_supplicant 2>/dev/null
                    sleep 1
                    /usr/bin/wpa_supplicant -B -i wlan0 -c "$WPA_CONF" 2>/dev/null
                    sleep 5
                    udhcpc -i wlan0 -q 2>/dev/null
                fi
            fi
            ;;
            
        "ON")  
            dialog --infobox "Reiniciando motor wpa_supplicant..." 3 40
            rfkill unblock wifi 2>/dev/null
            ip link set wlan0 up 2>/dev/null
            killall -9 wpa_supplicant 2>/dev/null
            /usr/bin/wpa_supplicant -B -i wlan0 -c "$WPA_CONF" 2>/dev/null
            sleep 3
            ;;
            
        "OFF") 
            dialog --infobox "Matando procesos de radio..." 3 40
            killall -9 wpa_supplicant 2>/dev/null
            ip link set wlan0 down 2>/dev/null
            rfkill block wifi 2>/dev/null
            sleep 2
            ;;
            
        "RESTART")
            dialog --infobox "Forzando cliente DHCP..." 3 40
            killall -9 udhcpc 2>/dev/null
            udhcpc -i wlan0 -q 2>/dev/null
            sleep 3
            ;;
            
        "STATUS")
            INFO=$(iw dev wlan0 link 2>/dev/null || echo "Desconectado")
            ROUTE=$(ip route | grep default || echo "Sin puerta de enlace")
            DNS=$(cat /etc/resolv.conf 2>/dev/null | grep nameserver | awk '{print $2}' | paste -sd ", " || echo "Sin DNS")
            dialog --title " DIAGNOSTICO DE RED " --msgbox "--- ENLACE FISICO ---\n$INFO\n\n--- RUTAS ---\n$ROUTE\n\n--- DNS ---\n$DNS" 20 70
            ;;
            
        "SALIR") break ;;
    esac
done
