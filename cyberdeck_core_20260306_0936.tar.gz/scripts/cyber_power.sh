#!/bin/sh
# CYBERDECK POWER MANAGER - SWAY NATIVE DAEMON

# 1. Pequeña pausa para asegurar que los mandos físicos estén registrados
sleep 5

# 2. Localizamos el mando dinámicamente
DEVICE=$(grep -E 'Handlers|Name' /proc/bus/input/devices | grep -A 1 "joypad\|vpgpad\|Gamepad" | grep -oE 'event[0-9]+' | head -n 1)
[ -z "$DEVICE" ] && DEVICE=$(ls /dev/input/event* 2>/dev/null | sort -V | tail -n 1 | cut -d/ -f4)
FULL_DEVICE="/dev/input/$DEVICE"

BACKLIGHT=$(ls -d /sys/class/backlight/* 2>/dev/null | head -n 1)

# Variables de control
IDLE_LIMIT=300
IDLE_COUNT=0
SCREEN_ON=1

turn_off() {
    if [ $SCREEN_ON -eq 1 ]; then
        swaymsg "output * dpms off" >/dev/null 2>&1
        [ -n "$BACKLIGHT" ] && echo 0 > "$BACKLIGHT/brightness" 2>/dev/null
        SCREEN_ON=0
    fi
}

turn_on() {
    if [ $SCREEN_ON -eq 0 ]; then
        swaymsg "output * dpms on" >/dev/null 2>&1
        [ -n "$BACKLIGHT" ] && echo 255 > "$BACKLIGHT/brightness" 2>/dev/null
        SCREEN_ON=1
    fi
    IDLE_COUNT=0
}

# 3. Bucle infinito
while true; do
    EVENT=$(timeout 1 dd if=$FULL_DEVICE bs=24 count=1 2>/dev/null | hexdump -v -e '24/1 "%02x "')
    
    if [ -z "$EVENT" ]; then
        IDLE_COUNT=$((IDLE_COUNT + 1))
        if [ $IDLE_COUNT -ge $IDLE_LIMIT ]; then
            turn_off
        fi
    else
        # Actividad detectada
        if [ $SCREEN_ON -eq 0 ]; then
            turn_on
            sleep 1
            continue
        fi
        
        IDLE_COUNT=0
        
        # Botón L2 detectado
        case "$EVENT" in
            *"01 00 38 01 01 00 00 00"*)
                turn_off
                sleep 1
                ;;
        esac
    fi
done
