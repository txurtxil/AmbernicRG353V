#!/bin/bash

echo "[*] 1. RECONSTRUYENDO SHELL PRINCIPAL (Sin errores de Window 1)..."
cat << 'WARROOM' > /storage/scripts/start_war_room.sh
#!/bin/bash
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C.UTF-8

# Creamos una sesión limpia de tmux (sin buscar ventanas que no existen)
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -A -s war_room "/bin/bash" 2> /storage/error_shell.log || {
    echo "======================================"
    echo "[!] TMUX HA FALLADO EN LA SHELL"
    echo "Revisa el error abajo:"
    cat /storage/error_shell.log
    echo "======================================"
    sleep 10
}
WARROOM
chmod +x /storage/scripts/start_war_room.sh

echo "[*] 2. RECONSTRUYENDO KALI MULTITAREA (Con tiempo de arranque)..."
cat << 'KALI' > /storage/scripts/start_kali_multitask.sh
#!/bin/bash
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C.UTF-8
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

# 1. Comprobamos si el motor Docker está vivo
if ! docker ps >/dev/null 2>&1; then
    echo "[!] ERROR GRAVE: Docker no responde."
    echo "El servicio dockerd no está corriendo."
    sleep 10
    exit 1
fi

# 2. Encendemos el núcleo de Kali y ESPERAMOS a que arranque
if ! docker ps | grep -q kali_core; then
    echo "[*] Levantando núcleo de Kali (Por favor espera 3 segundos)..."
    docker run -d --rm --name kali_core --net=host --privileged kali-cyberdeck:latest sleep infinity > /storage/error_kali_docker.log 2>&1
    # EL SECRETO: Darle tiempo al contenedor para encenderse antes de atacarlo
    sleep 3 
fi

# 3. Lanzamos el entorno multipanel (Congelando la pantalla si algo falla)
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s kali_tactico "docker exec -it kali_core /bin/bash || { echo '[!] Fallo al cargar shell principal'; sleep 10; }"
/storage/scripts/bin/tmux split-window -h -t kali_tactico "docker exec -it kali_core watch -n 2 'netstat -tulnp | grep LISTEN' || { echo '[!] Fallo al cargar monitor de red'; sleep 10; }"
/storage/scripts/bin/tmux split-window -v -t kali_tactico "docker exec -it kali_core htop || { echo '[!] Fallo al cargar htop (¿Está instalado en Kali?)'; sleep 10; }"

/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux attach-session -t kali_tactico 2> /storage/error_kali_tmux.log || {
    echo "[!] TMUX HA FALLADO AL MOSTRAR KALI:"
    cat /storage/error_kali_tmux.log
    sleep 10
}
KALI
chmod +x /storage/scripts/start_kali_multitask.sh

echo "[*] 3. ACTUALIZANDO EL MENÚ PARA CAZAR EL FALLO DE GTOP..."
sed -i 's|"LC_ALL=C.UTF-8 gtop --utf-force"|"LC_ALL=C.UTF-8 gtop --utf-force || { echo \\"======================================\\"; echo \\"[!] ERROR: gtop no se ha podido ejecutar.\\"; echo \\"Es probable que falte NodeJS en el sistema.\\"; echo \\"======================================\\"; sleep 10; }"|g' /storage/main_menu.sh

echo ">>> CAZADOR INSTALADO. Lanza el menú y entra a las opciones que fallaban."
