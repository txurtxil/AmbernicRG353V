#!/bin/sh
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"

/storage/scripts/bin/tmux kill-session -t war_room 2>/dev/null
sleep 0.5

if ! docker ps >/dev/null 2>&1; then
    /storage/scripts/start_docker_daemon.sh
    sleep 3
fi

# EL ARREGLO DE MC: Montamos los volumenes (-v) y fijamos el directorio (-w) al arrancar el nucleo
if ! docker ps | grep -q kali_core; then
    docker run -d --rm --name kali_core --net=host --pid=host --privileged -v /:/host_root -v /storage:/storage -w /storage kali-cyberdeck:latest sleep infinity
fi

/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s war_room -n "Admin" "/bin/sh"

# Como el contenedor ahora nace en /storage, MC abrira alli por defecto
/storage/scripts/bin/tmux split-window -h -t war_room:Admin "docker exec -it kali_core mc || /bin/sh"

/storage/scripts/bin/tmux select-pane -t war_room:Admin.0
/storage/scripts/bin/tmux split-window -v -t war_room:Admin "docker exec -it kali_core htop || /bin/sh"

/storage/scripts/bin/tmux select-pane -t war_room:Admin.0
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room -n "SSH" "/storage/scripts/ssh_launcher.sh"
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-window -t war_room -n "Shell" "/bin/sh"

/storage/scripts/bin/tmux select-window -t war_room:Admin
/storage/scripts/bin/tmux attach-session -t war_room
clear
