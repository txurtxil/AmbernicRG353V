#!/bin/sh
export TERM=foot
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m'

while true; do
    clear
    echo -e "${BLUE}======================================"
    echo -e "      💀 CYBERDECK ADVANCED OPS 💀"
    echo -e "======================================"
    echo -e "${GREEN}1)${NC} PENTEST: Escaneo de Puertos (nmap)"
    echo -e "${GREEN}2)${NC} SNIFFER: Ver Tráfico Red (tcpdump)"
    echo -e "${GREEN}3)${NC} WINE: Configuración (winecfg)"
    echo -e "${GREEN}4)${NC} WINE: Explorador de Windows (.exe)"
    echo -e "${GREEN}5)${NC} WIFI: Escaneo de Servicios (connman)"
    echo -e "${GREEN}6)${NC} Salir"
    echo -e "${BLUE}======================================${NC}"
    echo -n "Selecciona: "
    read opt
    case $opt in
        1) echo "Escribe la IP a escanear:"; read ip; nmap -F $ip ; read -p "..." ;;
        2) tcpdump -i wlan0 -c 50 ; read -p "..." ;;
        3) winecfg ;;
        4) wine winefile ;;
        5) connmanctl services ; read -p "..." ;;
        6) exit ;;
    esac
done
