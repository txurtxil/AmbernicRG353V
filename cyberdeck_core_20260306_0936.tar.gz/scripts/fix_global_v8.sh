#!/bin/bash

echo "[*] 1. SOLUCIONANDO DOCKER Y TERMINFO EN LA SHELL GLOBAL..."
# Inyectamos el PATH de Docker en los perfiles de la terminal para que funcione siempre
echo 'export PATH=$PATH:/storage/scripts/docker/bin' >> ~/.profile 2>/dev/null
echo 'export PATH=$PATH:/storage/scripts/docker/bin' >> ~/.bashrc 2>/dev/null
export PATH=$PATH:/storage/scripts/docker/bin

echo "[*] 2. RECONSTRUYENDO MODO KALI TÁCTICO (Multipanel Tmux)..."
cat << 'KALI' > /storage/scripts/start_kali_multitask.sh
#!/bin/bash
# 1. Forzamos las variables vitales para evitar el cuelgue de Terminfo y UTF-8
export TERMINFO=/storage/terminfo
export TERM=linux
export LC_ALL=C.UTF-8
export PATH=$PATH:/storage/scripts/docker/bin

# 2. Arrancar el contenedor "núcleo" de Kali en background (si no está ya corriendo)
if ! docker ps | grep -q kali_core; then
    docker run -d --rm --name kali_core --net=host --privileged kali-cyberdeck:latest sleep infinity
fi

# 3. Crear la sesión táctica en Tmux dividida en 4 paneles
# Panel 1 (Principal): Shell libre
/storage/scripts/bin/tmux -f /storage/.tmux.conf new-session -d -s kali_tactico "docker exec -it kali_core /bin/bash"

# Panel 2 (Derecha): Monitorización de puertos de red en tiempo real
/storage/scripts/bin/tmux split-window -h -t kali_tactico "docker exec -it kali_core watch -n 2 'netstat -tulnp | grep LISTEN'"

# Panel 3 (Inferior Derecha): Htop de recursos internos del contenedor
/storage/scripts/bin/tmux split-window -v -t kali_tactico "docker exec -it kali_core htop"

# Panel 4 (Inferior Izquierda): Shell preparada para escanear con Nmap
/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux split-window -v -t kali_tactico "docker exec -it kali_core /bin/bash -c 'echo \"[+] Listo para escanear la red (ej: nmap -sn 192.168.1.0/24)\"; exec /bin/bash'"

# Volver al panel principal y adjuntar a la pantalla
/storage/scripts/bin/tmux select-pane -t kali_tactico:0.0
/storage/scripts/bin/tmux attach-session -t kali_tactico
KALI
chmod +x /storage/scripts/start_kali_multitask.sh

echo "[*] 3. ACTUALIZANDO EL MENÚ PRINCIPAL (GTOP Y COLORES NUEVOS)..."
# Cambiamos el color a un tema Oscuro/Verde mucho más profesional
sed -i 's/screen_color =.*/screen_color = (GREEN,BLACK,ON)/' /storage/.dialogrc_main 2>/dev/null
sed -i 's/title_color =.*/title_color = (WHITE,BLACK,ON)/' /storage/.dialogrc_main 2>/dev/null

cat << 'MENU' > /storage/main_menu.sh
#!/bin/sh
# Garantizamos soporte UTF-8 global
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
export TERM=linux
export TERMINFO=/storage/terminfo

DOCKER="/storage/scripts/docker/bin/docker"
export DOCKER_HOST="unix:///storage/scripts/docker/run/docker.sock"
export PATH=$PATH:/storage/scripts/docker/bin:/storage/scripts/bin

# Carga de módulos
modprobe joydev 2>/dev/null
modprobe uinput 2>/dev/null
chmod 666 /dev/uinput 2>/dev/null

# Reinicio del ratón y teclado
killall -9 gptokeyb 2>/dev/null
pkill -9 -f l1_listener.sh 2>/dev/null
export SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1
export SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1

/usr/bin/gptokeyb "foot" -c "/storage/scripts/keyb/universal.gptk" &
nohup /storage/scripts/keyb/l1_listener.sh > /dev/null 2>&1 &

get_stats() {
    IP=$(ip route get 1 2>/dev/null | awk '{print $7;exit}' || echo "OFFLINE")
    BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "??")
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null | awk '{print int($1/1000)}')
    echo "[ IP: $IP | BAT: $BAT% | TEMP: $TEMP'C ]"
}

while true; do
    INFO=$(get_stats)
    export DIALOGRC=/storage/.dialogrc_main
    
    dialog --timeout 60 --ascii-lines --shadow --clear \
    --backtitle "CyberDeck OS - SISTEMA CENTRAL" \
    --title " $INFO " \
    --menu "SELECCIONA MÓDULO" 18 64 8 \
    "SHELL"    "Terminal Principal" \
    "DEV"      "Entorno de Desarrollo" \
    "GTOP"     "Monitor de Sistema (Gtop)" \
    "KALI"     "Suite Ofensiva Kali (Multitarea)" \
    "SETTINGS" "Ajustes del Sistema" \
    "EXIT"     "Salir a Terminal Plana" 2> /tmp/choice.txt
    
    [ $? -ne 0 ] && continue
    CHOICE=$(cat /tmp/choice.txt | tr -d '[:space:]')
    clear
    
    case "$CHOICE" in
        "SHELL") 
            if [ -f "/storage/scripts/start_war_room.sh" ]; then
                /storage/scripts/start_war_room.sh
            else
                /bin/sh
            fi
            ;;
        "DEV")
            if [ -f "/storage/scripts/submenu_desarrollo.sh" ]; then
                /storage/scripts/submenu_desarrollo.sh
            fi
            ;;
        "GTOP")  
            # Gtop inyectado con el parámetro forzado UTF-8
            /storage/scripts/bin/tmux new-session -A -s gtop "LC_ALL=C.UTF-8 gtop --utf-force" 
            ;;
        "KALI")  
            export DIALOGRC=/storage/.dialogrc_kali
            dialog --msgbox "Desplegando entorno táctico de Kali..." 5 45
            /storage/scripts/start_kali_multitask.sh 
            ;;
        "SETTINGS") 
            if [ -f "/storage/scripts/settings_tmux.sh" ]; then
                /storage/scripts/settings_tmux.sh
            fi
            ;;
        "EXIT") 
            break 
            ;;
    esac
done
MENU
chmod +x /storage/main_menu.sh

echo ">>> TODOS LOS PROBLEMAS CORREGIDOS. Ya puedes disfrutar del nuevo entorno."
