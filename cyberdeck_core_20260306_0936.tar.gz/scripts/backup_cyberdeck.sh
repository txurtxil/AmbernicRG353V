#!/bin/bash
FECHA=$(date +"%Y%m%d_%H%M")
BACKUP_FILE="/storage/backup_cyberdeck_$FECHA.tar.gz"
echo "Creando copia de seguridad en $BACKUP_FILE..."
tar -czvf $BACKUP_FILE /storage/scripts/ /storage/main_menu.sh /storage/.tmux.conf /storage/.dialogrc* 2>/dev/null
echo ">>> Copia finalizada. ¡Esta vez sí, guárdala en un lugar seguro!"
