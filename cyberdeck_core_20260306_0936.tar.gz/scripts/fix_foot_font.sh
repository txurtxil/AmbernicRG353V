#!/bin/sh

echo "[*] AJUSTANDO MOTOR DE RENDERIZADO DEL TERMINAL (FOOT)..."

# Aseguramos que el directorio existe
mkdir -p /storage/.config/foot/

# Escribimos el archivo limpio y con la fuente activada
cat << 'INI' > /storage/.config/foot/foot.ini
[main]
# Nacer siempre ocupando toda la pantalla
initial-window-mode=fullscreen

# FUENTE ACTIVADA: Este es el secreto de la pantalla completa
font=monospace:size=16
INI

echo ">>> TAMAÑO DE LETRA RESTAURADO."
